/**
 * study.js
 * Redesigned Complete Study Engine:
 * - Dual Mode: "Count-Up Stopwatch" (Track how much you study) + "Countdown Target" (Curated/Custom intervals)
 * - 18 curated study templates (managed in Settings & Quick target selector)
 * - Daily Study Routine planner (checklist of study blocks, time slots, per-day tracking)
 * - Interactive Monthly Study Calendar & Activity Heatmap (view previous days' study time & history)
 * - Timestamp-resilient calculation (accurate across browser throttling, locking, tab sleeps, refresh)
 * - Task tagging & active task display
 * - Focus scratchpad notes (auto-saved)
 * - Web Audio API ambient sounds (pure vanilla, zero external assets)
 * - True fullscreen Focus mode
 * - Daily targets & streak tracking
 */

import { getData, updateData, addHistory } from "./storage.js";

export const STUDY_TEMPLATES = [
  {
    id: "classic",
    name: "Classic Study",
    studyMin: 25,
    breakMin: 5,
    targetSessions: 4,
    desc: "Standard balanced interval for steady focus",
  },
  {
    id: "focus-mode",
    name: "Focus Mode",
    studyMin: 45,
    breakMin: 10,
    targetSessions: 3,
    desc: "Extended focus block for complex material",
  },
  {
    id: "deep-study",
    name: "Deep Study",
    studyMin: 60,
    breakMin: 15,
    targetSessions: 3,
    desc: "High-intensity immersion for challenging topics",
  },
  {
    id: "pomodoro",
    name: "Pomodoro Study",
    studyMin: 25,
    breakMin: 5,
    targetSessions: 4,
    desc: "Traditional 25m interval with 5m restoration break",
  },
  {
    id: "25-5",
    name: "25/5 Study",
    studyMin: 25,
    breakMin: 5,
    targetSessions: 4,
    desc: "High repetition 25 min cycle with quick breaks",
  },
  {
    id: "50-10",
    name: "50/10 Study",
    studyMin: 50,
    breakMin: 10,
    targetSessions: 3,
    desc: "50 min solid study session with 10 min refresh",
  },
  {
    id: "90-20",
    name: "90/20 Study",
    studyMin: 90,
    breakMin: 20,
    targetSessions: 2,
    desc: "Ultradian rhythm deep work and full recovery",
  },
  {
    id: "exam-mode",
    name: "Exam Mode",
    studyMin: 120,
    breakMin: 15,
    targetSessions: 2,
    desc: "Simulated 2-hour exam practice sprint",
  },
  {
    id: "reading-mode",
    name: "Reading Mode",
    studyMin: 30,
    breakMin: 5,
    targetSessions: 4,
    desc: "Gentle pacing for textbook and literature reading",
  },
  {
    id: "revision-mode",
    name: "Revision Mode",
    studyMin: 40,
    breakMin: 10,
    targetSessions: 3,
    desc: "Reviewing lecture notes and flashcard decks",
  },
  {
    id: "practice-mode",
    name: "Practice Mode",
    studyMin: 50,
    breakMin: 10,
    targetSessions: 3,
    desc: "Problem solving, mathematical drills, and coding",
  },
  {
    id: "short-session",
    name: "Short Session",
    studyMin: 15,
    breakMin: 3,
    targetSessions: 4,
    desc: "Quick bite-sized review for tight schedules",
  },
  {
    id: "long-session",
    name: "Long Session",
    studyMin: 90,
    breakMin: 20,
    targetSessions: 2,
    desc: "Comprehensive extended study marathon",
  },
  {
    id: "silent-study",
    name: "Silent Study",
    studyMin: 45,
    breakMin: 10,
    targetSessions: 3,
    desc: "Quiet study chamber mindset with zero distractions",
  },
  {
    id: "minimal-study",
    name: "Minimal Study",
    studyMin: 30,
    breakMin: 5,
    targetSessions: 4,
    desc: "Clean stripped-down session focusing only on time",
  },
  {
    id: "night-study",
    name: "Night Study",
    studyMin: 60,
    breakMin: 10,
    targetSessions: 2,
    desc: "Evening focus tuned for calm late-night concentration",
  },
  {
    id: "fullscreen-study",
    name: "Fullscreen Study",
    studyMin: 45,
    breakMin: 10,
    targetSessions: 3,
    desc: "Immersive layout prioritizing large timer view",
  },
  {
    id: "custom-study",
    name: "Custom Study",
    studyMin: 30,
    breakMin: 5,
    targetSessions: 4,
    desc: "User-defined study and break durations",
  },
];

let studyInterval = null;
let currentTemplateId = "classic";
let currentTrackingMode = "countup"; // 'countup' | 'countdown'
let selectedTargetMinutes = 25;

// Active state object
let activeStudy = null;

// Calendar State
let calCurrentYear = new Date().getFullYear();
let calCurrentMonth = new Date().getMonth(); // 0-indexed
let calSelectedDate = new Date().toISOString().split("T")[0];

// Ambient sound state (Web Audio API)
let audioCtx = null;
let ambientSource = null;
let ambientGain = null;
let isSoundPlaying = false;
let studyListenersAttached = false;
let isFullscreenStudy = false;

export function initStudy() {
  const data = getData();
  const savedState = data.studyState?.activeSession;
  currentTrackingMode = data.studyState?.trackingMode || "countup";

  // Check and reset daily routine if date changed
  checkAndResetDailyRoutines();

  if (
    savedState &&
    (savedState.status === "studying" ||
      savedState.status === "paused" ||
      savedState.status === "break")
  ) {
    restoreStudySession(savedState);
  } else {
    currentTemplateId = data.settings.study?.defaultTemplate || "classic";
    resetToReadyState();
  }

  renderStudyUI();
  renderSubtasks();
  updateDailyGoalDisplay();
  renderRoutinesList();
  renderStudyCalendar();
  updateStudyMetrics();
  attachStudyListeners();
}

function checkAndResetDailyRoutines() {
  const data = getData();
  const todayStr = new Date().toISOString().split("T")[0];
  const lastRoutineDate = data.studyState?.routineDate;

  if (lastRoutineDate && lastRoutineDate !== todayStr) {
    const existingRoutines = (data.studyState?.routines || []).map((r) => ({
      ...r,
      completed: false,
    }));
    updateData({
      studyState: {
        ...(data.studyState || {}),
        routineDate: todayStr,
        routines: existingRoutines,
      },
    });
  } else if (!lastRoutineDate) {
    updateData({
      studyState: {
        ...(data.studyState || {}),
        routineDate: todayStr,
      },
    });
  }
}

function attachStudyListeners() {
  if (studyListenersAttached) return;
  studyListenersAttached = true;

  // Mode Switch Tabs (Count-Up vs Countdown)
  const tabCountup = document.getElementById("tab-study-countup");
  const tabCountdown = document.getElementById("tab-study-countdown");

  tabCountup?.addEventListener("click", () => {
    switchTrackingMode("countup");
  });

  tabCountdown?.addEventListener("click", () => {
    switchTrackingMode("countdown");
  });

  // Quick Target Buttons (Countdown mode)
  document.querySelectorAll(".quick-target-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const min = parseInt(btn.getAttribute("data-target-min"), 10) || 25;
      selectQuickTargetMinutes(min);
    });
  });

  // Task Input Auto-Save
  const taskInput = document.getElementById("study-task-input");
  if (taskInput) {
    taskInput.addEventListener("input", (e) => {
      if (activeStudy) {
        activeStudy.taskName = e.target.value.trim();
        saveActiveStudyToStorage();
      }
      updateData({
        studyState: {
          ...(getData().studyState || {}),
          currentTask: e.target.value.trim(),
        },
      });
    });
  }

  // Focus Scratchpad Auto-Save
  const scratchpad = document.getElementById("study-scratchpad");
  if (scratchpad) {
    scratchpad.value = getData().studyState?.notes || "";
    scratchpad.addEventListener("input", (e) => {
      updateData({
        studyState: {
          ...(getData().studyState || {}),
          notes: e.target.value,
        },
      });
    });
  }

  // Routine Form Toggles
  const btnAddRoutine = document.getElementById("btn-add-routine-item");
  const routineForm = document.getElementById("study-routine-form");
  const btnCancelRoutine = document.getElementById("btn-cancel-routine-form");

  btnAddRoutine?.addEventListener("click", () => {
    if (routineForm) {
      routineForm.style.display = routineForm.style.display === "none" ? "flex" : "none";
      if (routineForm.style.display === "flex") {
        document.getElementById("routine-title-input")?.focus();
      }
    }
  });

  btnCancelRoutine?.addEventListener("click", () => {
    if (routineForm) routineForm.style.display = "none";
  });

  routineForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    const titleInput = document.getElementById("routine-title-input");
    const timeInput = document.getElementById("routine-time-input");
    if (!titleInput || !titleInput.value.trim()) return;

    const data = getData();
    const currentRoutines = data.studyState?.routines || [];
    const newRoutine = {
      id: `rt_${Date.now()}`,
      title: titleInput.value.trim(),
      time: timeInput?.value.trim() || "Anytime",
      targetMin: 60,
      completed: false,
    };

    updateData({
      studyState: {
        ...(data.studyState || {}),
        routines: [...currentRoutines, newRoutine],
      },
    });

    titleInput.value = "";
    if (timeInput) timeInput.value = "";
    routineForm.style.display = "none";
    renderRoutinesList();
  });

  // Calendar Controls
  document.getElementById("btn-cal-prev")?.addEventListener("click", () => {
    calCurrentMonth--;
    if (calCurrentMonth < 0) {
      calCurrentMonth = 11;
      calCurrentYear--;
    }
    renderStudyCalendar();
  });

  document.getElementById("btn-cal-next")?.addEventListener("click", () => {
    calCurrentMonth++;
    if (calCurrentMonth > 11) {
      calCurrentMonth = 0;
      calCurrentYear++;
    }
    renderStudyCalendar();
  });

  document.getElementById("btn-cal-today")?.addEventListener("click", () => {
    const today = new Date();
    calCurrentYear = today.getFullYear();
    calCurrentMonth = today.getMonth();
    calSelectedDate = today.toISOString().split("T")[0];
    renderStudyCalendar();
    updateCalendarSelectedDateSummary();
  });

  // Ambient sound toggle
  const soundBtn = document.getElementById("btn-study-ambient-sound");
  if (soundBtn) {
    soundBtn.addEventListener("click", toggleAmbientSound);
  }

  // Fullscreen study toggle
  const fsBtn = document.getElementById("btn-study-fullscreen");
  if (fsBtn) {
    fsBtn.addEventListener("click", toggleFullscreenStudy);
  }

  // Shortcut to Settings
  const gotoSettingsBtn = document.getElementById("btn-goto-study-settings");
  if (gotoSettingsBtn) {
    gotoSettingsBtn.addEventListener("click", () => {
      const settingsNav = document.querySelector("[data-nav-view='settings']");
      if (settingsNav) settingsNav.click();
    });
  }

  // Sub-Tasks Checklist Form
  const subtaskForm = document.getElementById("study-subtask-form");
  const subtaskInput = document.getElementById("study-subtask-input");
  subtaskForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!subtaskInput || !subtaskInput.value.trim()) return;
    addSubtask(subtaskInput.value.trim());
    subtaskInput.value = "";
  });

  const clearDoneBtn = document.getElementById("btn-clear-completed-subtasks");
  clearDoneBtn?.addEventListener("click", () => {
    clearCompletedSubtasks();
  });

  // Daily Study Goal Preset Chips
  document.querySelectorAll(".goal-preset-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const minutes = parseInt(chip.getAttribute("data-goal"), 10) || 120;
      setDailyStudyGoal(minutes);
    });
  });

  // Edit Daily Study Goal Modal
  const editGoalBtn = document.getElementById("btn-edit-daily-goal");
  const goalModal = document.getElementById("modal-study-goal");
  const closeGoalModalBtn = document.getElementById("btn-close-goal-modal");
  const cancelGoalModalBtn = document.getElementById("btn-cancel-goal-modal");
  const customGoalForm = document.getElementById("form-custom-daily-goal");
  const inputGoalVal = document.getElementById("input-goal-value");
  const selectGoalUnit = document.getElementById("select-goal-unit");

  editGoalBtn?.addEventListener("click", () => {
    if (goalModal) {
      goalModal.style.display = "flex";
      const current = getData().settings.study?.dailyGoalMinutes || 120;
      if (inputGoalVal) {
        if (current >= 60 && current % 60 === 0) {
          inputGoalVal.value = current / 60;
          if (selectGoalUnit) selectGoalUnit.value = "hours";
        } else {
          inputGoalVal.value = current;
          if (selectGoalUnit) selectGoalUnit.value = "minutes";
        }
        inputGoalVal.focus();
      }
    }
  });

  closeGoalModalBtn?.addEventListener("click", () => {
    if (goalModal) goalModal.style.display = "none";
  });

  cancelGoalModalBtn?.addEventListener("click", () => {
    if (goalModal) goalModal.style.display = "none";
  });

  goalModal?.addEventListener("click", (e) => {
    if (e.target === goalModal) goalModal.style.display = "none";
  });

  document.querySelectorAll(".goal-modal-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const min = parseInt(chip.getAttribute("data-min"), 10);
      if (min > 0) {
        setDailyStudyGoal(min);
        if (goalModal) goalModal.style.display = "none";
      }
    });
  });

  customGoalForm?.addEventListener("submit", (e) => {
    e.preventDefault();
    if (!inputGoalVal) return;
    const rawVal = parseFloat(inputGoalVal.value);
    if (isNaN(rawVal) || rawVal <= 0) return;
    const unit = selectGoalUnit?.value || "hours";
    const minutes = unit === "hours" ? Math.round(rawVal * 60) : Math.round(rawVal);
    setDailyStudyGoal(minutes);
    if (goalModal) goalModal.style.display = "none";
  });

  // Timestamp calibration on tab visibility change
  document.addEventListener("visibilitychange", handleVisibilityChange);
}

function switchTrackingMode(mode) {
  if (currentTrackingMode === mode) return;

  if (
    activeStudy &&
    (activeStudy.status === "studying" || activeStudy.status === "paused")
  ) {
    if (!confirm("Switching mode will end the ongoing session. Proceed?")) {
      return;
    }
    stopStudyInterval();
    stopAmbientSound();
    recordSessionHistory("incomplete");
  }

  currentTrackingMode = mode;
  updateData({
    studyState: {
      ...(getData().studyState || {}),
      trackingMode: mode,
    },
  });

  resetToReadyState();
  renderStudyUI();
}

function selectQuickTargetMinutes(min) {
  selectedTargetMinutes = min;
  document.querySelectorAll(".quick-target-btn").forEach((b) => {
    const bMin = parseInt(b.getAttribute("data-target-min"), 10);
    if (bMin === min) {
      b.classList.add("active");
    } else {
      b.classList.remove("active");
    }
  });

  if (currentTrackingMode === "countdown" && activeStudy.status === "ready") {
    resetToReadyState();
    renderStudyUI();
  }
}

function handleVisibilityChange() {
  if (
    document.visibilityState === "visible" &&
    activeStudy &&
    (activeStudy.status === "studying" || activeStudy.status === "break")
  ) {
    tickStudy();
  }
}

function resetToReadyState() {
  const data = getData();
  const tmpl = STUDY_TEMPLATES.find((t) => t.id === currentTemplateId) || STUDY_TEMPLATES[0];
  const todayCount = data.studyState?.completedCountToday || 0;
  const currentTask = data.studyState?.currentTask || "";

  let plannedDuration = 0;
  let remaining = 0;

  if (currentTrackingMode === "countdown") {
    plannedDuration = (selectedTargetMinutes || tmpl.studyMin) * 60;
    remaining = plannedDuration;
  } else {
    // Count-up mode
    plannedDuration = 0;
    remaining = 0; // Starts from 0:00:00
  }

  activeStudy = {
    id: `study_${Date.now()}`,
    trackingMode: currentTrackingMode,
    templateId: tmpl.id,
    templateName:
      currentTrackingMode === "countup"
        ? "Stopwatch Study"
        : `${selectedTargetMinutes}m Countdown`,
    taskName: currentTask,
    mode: "study",
    status: "ready",
    plannedDurationSeconds: plannedDuration,
    remainingSeconds: remaining, // In countup, this tracks elapsed seconds
    elapsedSeconds: 0,
    startedAt: null,
    endTimestamp: null,
    pausedAt: null,
    completedSessions: todayCount,
    targetSessions: tmpl.targetSessions || 4,
  };

  saveActiveStudyToStorage();
}

function restoreStudySession(saved) {
  activeStudy = { ...saved };
  currentTrackingMode = saved.trackingMode || "countup";
  currentTemplateId = saved.templateId || "classic";

  if (activeStudy.status === "studying" || activeStudy.status === "break") {
    const now = Date.now();
    if (currentTrackingMode === "countdown") {
      const remainingMs = activeStudy.endTimestamp - now;
      if (remainingMs <= 0) {
        completeCurrentPhase();
        return;
      } else {
        activeStudy.remainingSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
        startStudyInterval();
        if (isSoundPlaying) startWhiteNoise();
      }
    } else {
      // Count-up mode restore
      const started = activeStudy.startedAt || now;
      activeStudy.elapsedSeconds = Math.max(0, Math.floor((now - started) / 1000));
      startStudyInterval();
      if (isSoundPlaying) startWhiteNoise();
    }
  }
}

function saveActiveStudyToStorage() {
  const data = getData();
  updateData({
    studyState: {
      ...(data.studyState || {}),
      activeSession: activeStudy,
    },
  });
  window.dispatchEvent(new CustomEvent("study-session-updated"));
}

export function selectStudyTemplate(templateId) {
  if (
    activeStudy &&
    (activeStudy.status === "studying" ||
      activeStudy.status === "break" ||
      activeStudy.status === "paused")
  ) {
    stopStudyInterval();
    stopAmbientSound();
    recordSessionHistory("incomplete");
  }

  currentTemplateId = templateId;
  const tmpl = STUDY_TEMPLATES.find((t) => t.id === templateId);
  if (tmpl) {
    selectedTargetMinutes = tmpl.studyMin;
  }
  resetToReadyState();
  renderStudyUI();
}

export function startStudy() {
  if (!activeStudy) resetToReadyState();

  const now = Date.now();
  activeStudy.startedAt = activeStudy.startedAt || now;
  activeStudy.mode = "study";
  activeStudy.status = "studying";
  activeStudy.pausedAt = null;

  if (currentTrackingMode === "countdown") {
    activeStudy.endTimestamp = now + activeStudy.remainingSeconds * 1000;
  } else {
    // Count-up mode
    activeStudy.endTimestamp = null;
    activeStudy.startedAt = now - (activeStudy.elapsedSeconds || 0) * 1000;
  }

  saveActiveStudyToStorage();
  startStudyInterval();
  if (isSoundPlaying) startWhiteNoise();
  renderStudyUI();
}

export function pauseStudy() {
  if (!activeStudy || (activeStudy.status !== "studying" && activeStudy.status !== "break")) return;

  stopStudyInterval();
  stopAmbientSound();
  const now = Date.now();
  activeStudy.pausedAt = now;

  if (currentTrackingMode === "countdown") {
    activeStudy.remainingSeconds = Math.max(0, Math.ceil((activeStudy.endTimestamp - now) / 1000));
  } else {
    activeStudy.elapsedSeconds = Math.max(0, Math.floor((now - activeStudy.startedAt) / 1000));
  }
  activeStudy.status = "paused";

  saveActiveStudyToStorage();
  renderStudyUI();
}

export function resumeStudy() {
  if (!activeStudy || activeStudy.status !== "paused") return;

  const now = Date.now();
  if (currentTrackingMode === "countdown") {
    activeStudy.endTimestamp = now + activeStudy.remainingSeconds * 1000;
  } else {
    activeStudy.startedAt = now - (activeStudy.elapsedSeconds || 0) * 1000;
  }
  activeStudy.pausedAt = null;
  activeStudy.status = activeStudy.mode === "break" ? "break" : "studying";

  saveActiveStudyToStorage();
  startStudyInterval();
  if (isSoundPlaying) startWhiteNoise();
  renderStudyUI();
}

export function applyNativeOverlayCommand(command, nativeStateJson = "") {
  let nativeState = {};
  try {
    nativeState = nativeStateJson ? JSON.parse(nativeStateJson) : {};
  } catch (_) {}

  if (!activeStudy) {
    const saved = getData().studyState?.activeSession;
    if (saved) {
      restoreStudySession(saved);
    } else {
      resetToReadyState();
    }
  }

  const seconds = Math.max(0, Number(nativeState.seconds || 0));
  const now = Date.now();
  const countdown = nativeState.countdown !== false;
  currentTrackingMode = countdown ? "countdown" : "countup";

  if (command === "pause") {
    stopStudyInterval();
    stopAmbientSound();
    if (countdown) {
      activeStudy.remainingSeconds = seconds;
      activeStudy.endTimestamp = null;
    } else {
      activeStudy.elapsedSeconds = seconds;
    }
    activeStudy.pausedAt = now;
    activeStudy.status = "paused";
    saveActiveStudyToStorage();
    renderStudyUI();
    return;
  }

  if (command === "resume") {
    if (countdown) {
      activeStudy.remainingSeconds = seconds;
      activeStudy.endTimestamp = now + seconds * 1000;
    } else {
      activeStudy.elapsedSeconds = seconds;
      activeStudy.startedAt = now - seconds * 1000;
      activeStudy.endTimestamp = null;
    }
    activeStudy.pausedAt = null;
    activeStudy.status = activeStudy.mode === "break" ? "break" : "studying";
    saveActiveStudyToStorage();
    startStudyInterval();
    renderStudyUI();
    return;
  }

  if (command === "start") {
    startStudy();
    return;
  }

  if (command === "stop") {
    endStudyEarly();
    return;
  }

  if (command === "complete") {
    completeCurrentPhase();
  }
}

export function endStudyEarly() {
  if (!activeStudy) return;

  stopStudyInterval();
  stopAmbientSound();

  // In count-up mode, ending naturally records the full studied time as completed!
  const isCountup = currentTrackingMode === "countup";
  const status = isCountup && (activeStudy.elapsedSeconds || 0) >= 30 ? "completed" : (isCountup ? "incomplete" : "incomplete");
  recordSessionHistory(status);

  if (status === "completed") {
    playChime();
    const data = getData();
    const newCount = (data.studyState?.completedCountToday || 0) + 1;
    updateData({
      studyState: {
        ...(data.studyState || {}),
        completedCountToday: newCount,
      },
    });
  }

  resetToReadyState();
  renderStudyUI();
  updateStudyMetrics();
  updateDailyGoalDisplay();
  renderStudyCalendar();
}

function startStudyInterval() {
  if (studyInterval) clearInterval(studyInterval);
  studyInterval = setInterval(tickStudy, 500);
}

function stopStudyInterval() {
  if (studyInterval) {
    clearInterval(studyInterval);
    studyInterval = null;
  }
}

function tickStudy() {
  if (!activeStudy) return;

  const now = Date.now();

  if (currentTrackingMode === "countdown") {
    if (!activeStudy.endTimestamp) return;
    const remainingMs = activeStudy.endTimestamp - now;

    if (remainingMs <= 0) {
      completeCurrentPhase();
    } else {
      activeStudy.remainingSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
      updateStudyDisplay();
    }
  } else {
    // Count-up mode
    if (!activeStudy.startedAt) return;
    activeStudy.elapsedSeconds = Math.max(0, Math.floor((now - activeStudy.startedAt) / 1000));
    updateStudyDisplay();
  }
}

function completeCurrentPhase() {
  stopStudyInterval();
  stopAmbientSound();
  playChime();

  if (activeStudy.mode === "study") {
    recordSessionHistory("completed");

    const data = getData();
    const newCount = (data.studyState?.completedCountToday || 0) + 1;
    activeStudy.completedSessions = newCount;
    updateData({
      studyState: {
        ...(data.studyState || {}),
        completedCountToday: newCount,
      },
    });

    const tmpl = STUDY_TEMPLATES.find((t) => t.id === currentTemplateId) || STUDY_TEMPLATES[0];
    const breakSec = (tmpl.breakMin || 5) * 60;
    const autoBreak = data.settings.study?.autoStartBreak;

    if (breakSec > 0) {
      activeStudy.mode = "break";
      activeStudy.status = autoBreak ? "break" : "ready";
      activeStudy.plannedDurationSeconds = breakSec;
      activeStudy.remainingSeconds = breakSec;
      activeStudy.startedAt = Date.now();
      activeStudy.endTimestamp = autoBreak ? Date.now() + breakSec * 1000 : null;

      saveActiveStudyToStorage();
      if (autoBreak) {
        startStudyInterval();
      }
      renderStudyUI();
    } else {
      activeStudy.status = "completed";
      saveActiveStudyToStorage();
      renderStudyUI();
    }
  } else if (activeStudy.mode === "break") {
    const data = getData();
    const autoNext = data.settings.study?.autoStartNextSession;

    resetToReadyState();
    if (autoNext) {
      startStudy();
    } else {
      renderStudyUI();
    }
  }

  updateStudyMetrics();
  updateDailyGoalDisplay();
  renderStudyCalendar();
}

function recordSessionHistory(status) {
  if (!activeStudy || !activeStudy.startedAt) return;

  const now = new Date();
  const start = new Date(activeStudy.startedAt);
  let duration = 0;

  if (currentTrackingMode === "countdown") {
    const planned = activeStudy.plannedDurationSeconds;
    const elapsed = Math.max(0, planned - activeStudy.remainingSeconds);
    duration = status === "completed" ? planned : elapsed;
  } else {
    duration = activeStudy.elapsedSeconds || 0;
  }

  if (duration <= 0) return;

  addHistory({
    type: "study",
    template: activeStudy.templateName || "Study Session",
    task: activeStudy.taskName || "",
    date: start.toISOString().split("T")[0],
    startTime: start.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    endTime: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    duration: duration,
    status: status,
  });
}

function formatTime(totalSeconds, includeHours = false) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  if (includeHours || h > 0) {
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function renderStudyUI() {
  const statusEl = document.getElementById("study-status-badge");
  const timeEl = document.getElementById("study-timer-display");
  const phaseLabelEl = document.getElementById("study-phase-label");
  const routinePillEl = document.getElementById("study-routine-tag");
  const progressFillEl = document.getElementById("study-progress-fill");
  const sessionCountEl = document.getElementById("study-completed-count");
  const actionsContainer = document.getElementById("study-actions-container");
  const taskInput = document.getElementById("study-task-input");
  const dotsContainer = document.getElementById("study-interval-dots");
  const quickTargetsRow = document.getElementById("study-quick-targets-row");

  // Mode Tabs Active State
  const tabCountup = document.getElementById("tab-study-countup");
  const tabCountdown = document.getElementById("tab-study-countdown");

  if (tabCountup && tabCountdown) {
    if (currentTrackingMode === "countup") {
      tabCountup.classList.add("active");
      tabCountdown.classList.remove("active");
      if (quickTargetsRow) quickTargetsRow.style.display = "none";
    } else {
      tabCountup.classList.remove("active");
      tabCountdown.classList.add("active");
      if (quickTargetsRow) quickTargetsRow.style.display = "flex";
    }
  }

  if (!timeEl || !activeStudy) return;

  // Status Badge
  if (statusEl) {
    let statusText = "Ready";
    let statusClass = "badge-ready";
    if (activeStudy.status === "studying") {
      statusText = "Studying";
      statusClass = "badge-studying";
    } else if (activeStudy.status === "paused") {
      statusText = "Paused";
      statusClass = "badge-paused";
    } else if (activeStudy.status === "break") {
      statusText = "Break";
      statusClass = "badge-break";
    } else if (activeStudy.status === "completed") {
      statusText = "Completed";
      statusClass = "badge-completed";
    }
    statusEl.textContent = statusText;
    statusEl.className = `status-badge ${statusClass}`;
  }

  // Routine / Phase Label
  if (routinePillEl) {
    if (currentTrackingMode === "countup") {
      routinePillEl.textContent = "Open Focus Stopwatch";
    } else {
      routinePillEl.textContent = `${selectedTargetMinutes}m Countdown Target`;
    }
  }

  if (phaseLabelEl) {
    if (activeStudy.mode === "break") {
      phaseLabelEl.textContent = "Rest & Recover Break";
    } else if (currentTrackingMode === "countup") {
      phaseLabelEl.textContent = "Track How Much You Study";
    } else {
      phaseLabelEl.textContent = `${activeStudy.templateName} Session`;
    }
  }

  // Sync Task Input
  if (taskInput && document.activeElement !== taskInput) {
    taskInput.value = activeStudy.taskName || "";
  }

  // Timer Digits
  if (currentTrackingMode === "countdown") {
    timeEl.textContent = formatTime(activeStudy.remainingSeconds);
  } else {
    // Count up format: HH:MM:SS
    timeEl.textContent = formatTime(activeStudy.elapsedSeconds || 0, true);
  }

  // Progress Bar
  if (progressFillEl) {
    if (currentTrackingMode === "countdown") {
      const planned = activeStudy.plannedDurationSeconds || 1;
      const progress = Math.min(
        100,
        Math.max(0, ((planned - activeStudy.remainingSeconds) / planned) * 100),
      );
      progressFillEl.style.width = `${progress}%`;
    } else {
      // In count-up, gentle pulse effect or 1 hour benchmark
      const hourProgress = Math.min(100, ((activeStudy.elapsedSeconds % 3600) / 3600) * 100);
      progressFillEl.style.width = `${hourProgress}%`;
    }
  }

  // Session Counter & Interval Dots
  if (sessionCountEl) {
    const count = getData().studyState?.completedCountToday || 0;
    sessionCountEl.textContent = `${count} Session${count === 1 ? "" : "s"} Completed Today`;
  }

  if (dotsContainer) {
    const completed = getData().studyState?.completedCountToday || 0;
    const target = 4;
    let dotsHtml = "";
    for (let i = 0; i < target; i++) {
      const isFilled = i < completed;
      const isCurrent = i === completed && activeStudy.status === "studying";
      dotsHtml += `<span class="interval-dot ${isFilled ? "filled" : ""} ${isCurrent ? "current" : ""}" title="Session ${i + 1}"></span>`;
    }
    dotsContainer.innerHTML = dotsHtml;
  }

  // Action Buttons
  if (actionsContainer) {
    if (activeStudy.status === "ready") {
      actionsContainer.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-start-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <span>${currentTrackingMode === "countup" ? "Start Studying" : "Start Target Focus"}</span>
        </button>
      `;
      document.getElementById("btn-start-study")?.addEventListener("click", startStudy);
    } else if (activeStudy.status === "studying" || activeStudy.status === "break") {
      actionsContainer.innerHTML = `
        <button type="button" class="btn btn-secondary" id="btn-pause-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          <span>Pause</span>
        </button>
        <button type="button" class="btn btn-danger" id="btn-end-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
          <span>${currentTrackingMode === "countup" ? "Finish Session" : "End Early"}</span>
        </button>
      `;
      document.getElementById("btn-pause-study")?.addEventListener("click", pauseStudy);
      document.getElementById("btn-end-study")?.addEventListener("click", endStudyEarly);
    } else if (activeStudy.status === "paused") {
      actionsContainer.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-resume-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <span>Resume</span>
        </button>
        <button type="button" class="btn btn-danger" id="btn-end-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
          <span>${currentTrackingMode === "countup" ? "Finish Session" : "End Early"}</span>
        </button>
      `;
      document.getElementById("btn-resume-study")?.addEventListener("click", resumeStudy);
      document.getElementById("btn-end-study")?.addEventListener("click", endStudyEarly);
    } else if (activeStudy.status === "completed") {
      actionsContainer.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-next-study">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <span>Start Another Session</span>
        </button>
      `;
      document.getElementById("btn-next-study")?.addEventListener("click", () => {
        resetToReadyState();
        startStudy();
      });
    }
  }
}

function updateStudyDisplay() {
  const timeEl = document.getElementById("study-timer-display");
  const progressFillEl = document.getElementById("study-progress-fill");
  if (!timeEl || !activeStudy) return;

  if (currentTrackingMode === "countdown") {
    timeEl.textContent = formatTime(activeStudy.remainingSeconds);
    if (progressFillEl) {
      const planned = activeStudy.plannedDurationSeconds || 1;
      const progress = Math.min(
        100,
        Math.max(0, ((planned - activeStudy.remainingSeconds) / planned) * 100),
      );
      progressFillEl.style.width = `${progress}%`;
    }
  } else {
    // Count-up format: HH:MM:SS
    timeEl.textContent = formatTime(activeStudy.elapsedSeconds || 0, true);
    if (progressFillEl) {
      const hourProgress = Math.min(100, (((activeStudy.elapsedSeconds || 0) % 3600) / 3600) * 100);
      progressFillEl.style.width = `${hourProgress}%`;
    }
  }

  // Update Daily Study Goal live display
  updateDailyGoalDisplay();
}

// ==========================================
// Daily Study Goal Progress Ring & Bar
// ==========================================
export function formatGoalMinutes(mins) {
  if (mins >= 60) {
    if (mins % 60 === 0) return `${mins / 60}h`;
    return `${Math.floor(mins / 60)}h ${mins % 60}m`;
  }
  return `${mins}m`;
}

export function setDailyStudyGoal(minutes) {
  const goal = Math.max(5, Math.round(Number(minutes) || 120));
  updateData({ settings: { study: { dailyGoalMinutes: goal } } });

  // Update chips active state
  document.querySelectorAll(".goal-preset-chip").forEach((chip) => {
    const val = parseInt(chip.getAttribute("data-goal"), 10);
    chip.classList.toggle("active", val === goal);
  });

  const chipLabel = document.getElementById("study-goal-target-chip");
  if (chipLabel) chipLabel.textContent = `${formatGoalMinutes(goal)}`;

  const settingsInput = document.getElementById("setting-study-daily-goal");
  if (settingsInput) settingsInput.value = goal;

  updateDailyGoalDisplay();
}

export function updateDailyGoalDisplay() {
  const data = getData();
  const goalMinutes = data.settings.study?.dailyGoalMinutes || 120;
  const todayStr = new Date().toISOString().split("T")[0];
  const todaySessions = (data.history || []).filter(
    (h) => h.type === "study" && h.date === todayStr,
  );
  let totalSecondsToday = todaySessions.reduce((acc, curr) => acc + (curr.duration || 0), 0);

  // If currently active and studying in countup or countdown, count running seconds live
  if (activeStudy && activeStudy.status === "studying" && activeStudy.mode !== "break") {
    totalSecondsToday += (activeStudy.elapsedSeconds || 0);
  }

  const todayMinutes = Math.round(totalSecondsToday / 60);
  const percent = Math.min(100, Math.round((todayMinutes / goalMinutes) * 100));
  const isGoalReached = todayMinutes >= goalMinutes;

  // Circular SVG Ring (r=30, circ=188.5)
  const ringCircle = document.getElementById("study-goal-ring-circle");
  if (ringCircle) {
    const circ = 188.5;
    const offset = circ - (circ * percent) / 100;
    ringCircle.style.strokeDashoffset = `${offset}`;
    ringCircle.classList.toggle("completed", isGoalReached);
  }

  const ringPercentText = document.getElementById("study-goal-ring-percent");
  if (ringPercentText) {
    ringPercentText.textContent = `${percent}%`;
  }

  const targetChip = document.getElementById("study-goal-target-chip");
  if (targetChip) {
    targetChip.textContent = `${formatGoalMinutes(goalMinutes)}`;
  }

  const progressText = document.getElementById("study-goal-progress-text");
  if (progressText) {
    const todayFmt = todayMinutes >= 60 ? `${Math.floor(todayMinutes / 60)}h ${todayMinutes % 60}m` : `${todayMinutes}m`;
    const goalFmt = goalMinutes >= 60 ? `${Math.floor(goalMinutes / 60)}h ${goalMinutes % 60}m` : `${goalMinutes}m`;
    progressText.textContent = `${todayFmt} / ${goalFmt} completed`;
  }

  const statusBadge = document.getElementById("study-goal-status-badge");
  if (statusBadge) {
    if (isGoalReached) {
      statusBadge.textContent = "Goal Achieved! 🎉";
      statusBadge.className = "badge-chip badge-completed";
      statusBadge.style.background = "var(--success-bg)";
      statusBadge.style.color = "var(--success)";
    } else {
      const remainingMin = Math.max(0, goalMinutes - todayMinutes);
      statusBadge.textContent = `${remainingMin}m left today`;
      statusBadge.className = "badge-chip";
      statusBadge.style.background = "";
      statusBadge.style.color = "";
    }
  }

  const barFill = document.getElementById("study-goal-bar-fill");
  if (barFill) {
    barFill.style.width = `${percent}%`;
    barFill.classList.toggle("completed", isGoalReached);
  }
}

// ==========================================
// Session Sub-Tasks Checklist Management
// ==========================================
export function renderSubtasks() {
  const container = document.getElementById("study-subtasks-list");
  if (!container) return;

  const data = getData();
  const subtasks = data.studyState?.subtasks || [];
  const total = subtasks.length;
  const completedCount = subtasks.filter((st) => st.completed).length;

  // Update badge and progress bar
  const badge = document.getElementById("subtasks-count-badge");
  if (badge) {
    badge.textContent = `${completedCount}/${total} Done`;
  }

  const fill = document.getElementById("subtask-progress-fill");
  if (fill) {
    const pct = total === 0 ? 0 : Math.round((completedCount / total) * 100);
    fill.style.width = `${pct}%`;
  }

  if (subtasks.length === 0) {
    container.innerHTML = `
      <div style="font-size: 0.82rem; color: var(--text-muted); text-align: center; padding: 14px 0;">
        No sub-tasks defined yet. Enter a sub-task above to track your session steps!
      </div>
    `;
    return;
  }

  container.innerHTML = subtasks
    .map(
      (st) => `
      <div class="subtask-item-row ${st.completed ? "completed" : ""}" data-subtask-id="${st.id}">
        <div class="subtask-item-left">
          <input 
            type="checkbox" 
            class="subtask-checkbox" 
            ${st.completed ? "checked" : ""} 
            data-toggle-subtask="${st.id}" 
            title="Mark sub-task completed"
          />
          <span class="subtask-item-text">${escapeHtml(st.text)}</span>
        </div>
        <button 
          type="button" 
          class="subtask-delete-btn" 
          data-delete-subtask="${st.id}" 
          title="Delete this sub-task"
        >
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
    `,
    )
    .join("");

  // Attach toggle listeners
  container.querySelectorAll(".subtask-checkbox").forEach((cb) => {
    cb.addEventListener("change", (e) => {
      const id = cb.getAttribute("data-toggle-subtask");
      toggleSubtask(id, e.target.checked);
    });
  });

  // Attach delete listeners
  container.querySelectorAll(".subtask-delete-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-delete-subtask");
      deleteSubtask(id);
    });
  });
}

export function addSubtask(text) {
  if (!text || !text.trim()) return;
  const data = getData();
  const currentSubtasks = data.studyState?.subtasks || [];
  const newItem = {
    id: `st_${Date.now()}`,
    text: text.trim(),
    completed: false,
  };

  updateData({
    studyState: {
      ...(data.studyState || {}),
      subtasks: [...currentSubtasks, newItem],
    },
  });

  renderSubtasks();
}

export function toggleSubtask(id, completed) {
  const data = getData();
  const currentSubtasks = data.studyState?.subtasks || [];
  const updated = currentSubtasks.map((st) => (st.id === id ? { ...st, completed } : st));

  updateData({
    studyState: {
      ...(data.studyState || {}),
      subtasks: updated,
    },
  });

  renderSubtasks();
}

export function deleteSubtask(id) {
  const data = getData();
  const currentSubtasks = data.studyState?.subtasks || [];
  const updated = currentSubtasks.filter((st) => st.id !== id);

  updateData({
    studyState: {
      ...(data.studyState || {}),
      subtasks: updated,
    },
  });

  renderSubtasks();
}

export function clearCompletedSubtasks() {
  const data = getData();
  const currentSubtasks = data.studyState?.subtasks || [];
  const updated = currentSubtasks.filter((st) => !st.completed);

  updateData({
    studyState: {
      ...(data.studyState || {}),
      subtasks: updated,
    },
  });

  renderSubtasks();
}

// ==========================================
// Daily Routine Management
// ==========================================
export function renderRoutinesList() {
  const container = document.getElementById("study-routine-list");
  if (!container) return;

  const data = getData();
  const routines = data.studyState?.routines || [];

  if (routines.length === 0) {
    container.innerHTML = `
      <div style="font-size: 0.8rem; color: var(--text-muted); text-align: center; padding: 12px 0;">
        No routine blocks yet. Tap "+ Add Block" to schedule today's routine.
      </div>
    `;
    return;
  }

  container.innerHTML = routines
    .map(
      (r) => `
      <div class="routine-item-row ${r.completed ? "completed" : ""}" data-routine-id="${r.id}">
        <div class="routine-item-left">
          <input type="checkbox" class="routine-checkbox" ${r.completed ? "checked" : ""} data-toggle-id="${r.id}" title="Mark completed"/>
          <div class="routine-text-wrap">
            <span class="routine-item-title">${escapeHtml(r.title)}</span>
            <span class="routine-item-time">${escapeHtml(r.time || "Anytime")}</span>
          </div>
        </div>
        <button type="button" class="routine-delete-btn" data-delete-id="${r.id}" title="Remove this routine item">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>
    `,
    )
    .join("");

  // Attach toggle listeners
  container.querySelectorAll(".routine-checkbox").forEach((cb) => {
    cb.addEventListener("change", (e) => {
      const id = cb.getAttribute("data-toggle-id");
      toggleRoutineCompleted(id, e.target.checked);
    });
  });

  // Attach delete listeners
  container.querySelectorAll(".routine-delete-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-delete-id");
      deleteRoutineItem(id);
    });
  });
}

function toggleRoutineCompleted(id, completed) {
  const data = getData();
  const updated = (data.studyState?.routines || []).map((r) =>
    r.id === id ? { ...r, completed } : r,
  );
  updateData({
    studyState: {
      ...(data.studyState || {}),
      routines: updated,
    },
  });
  renderRoutinesList();
}

function deleteRoutineItem(id) {
  const data = getData();
  const updated = (data.studyState?.routines || []).filter((r) => r.id !== id);
  updateData({
    studyState: {
      ...(data.studyState || {}),
      routines: updated,
    },
  });
  renderRoutinesList();
}

// ==========================================
// Monthly Study Calendar & Activity Heatmap
// ==========================================
export function renderStudyCalendar() {
  const monthYearLabel = document.getElementById("calendar-month-year");
  const daysGrid = document.getElementById("calendar-days-grid");
  if (!daysGrid) return;

  const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December",
  ];

  if (monthYearLabel) {
    monthYearLabel.textContent = `${monthNames[calCurrentMonth]} ${calCurrentYear}`;
  }

  const data = getData();
  const historyList = data.history || [];

  // Map study seconds per date YYYY-MM-DD
  const dateStudyMap = {};
  historyList.forEach((h) => {
    if (h.type === "study" && h.date) {
      dateStudyMap[h.date] = (dateStudyMap[h.date] || 0) + (h.duration || 0);
    }
  });

  const firstDay = new Date(calCurrentYear, calCurrentMonth, 1).getDay(); // 0 is Sunday
  const daysInMonth = new Date(calCurrentYear, calCurrentMonth + 1, 0).getDate();
  const daysInPrevMonth = new Date(calCurrentYear, calCurrentMonth, 0).getDate();

  const todayStr = new Date().toISOString().split("T")[0];

  let gridHtml = "";

  // Previous month trailing days
  for (let i = firstDay - 1; i >= 0; i--) {
    const dayNum = daysInPrevMonth - i;
    gridHtml += `<div class="cal-day-cell other-month">${dayNum}</div>`;
  }

  // Current month days
  for (let day = 1; day <= daysInMonth; day++) {
    const mm = String(calCurrentMonth + 1).padStart(2, "0");
    const dd = String(day).padStart(2, "0");
    const dateStr = `${calCurrentYear}-${mm}-${dd}`;

    const isToday = dateStr === todayStr;
    const isSelected = dateStr === calSelectedDate;
    const studySec = dateStudyMap[dateStr] || 0;
    const hasStudy = studySec > 0;
    const isHighStudy = studySec >= 3600; // >1 hour

    gridHtml += `
      <div 
        class="cal-day-cell ${isToday ? "is-today" : ""} ${isSelected ? "is-selected" : ""} ${hasStudy ? "has-study" : ""} ${isHighStudy ? "high-study" : ""}" 
        data-date="${dateStr}" 
        title="${dateStr}: ${Math.round(studySec / 60)}m studied"
      >
        <span>${day}</span>
        ${hasStudy ? '<span class="cal-study-dot"></span>' : ""}
      </div>
    `;
  }

  // Trailing next month days to complete grid
  const totalCells = (firstDay + daysInMonth);
  const trailingCells = (7 - (totalCells % 7)) % 7;
  for (let i = 1; i <= trailingCells; i++) {
    gridHtml += `<div class="cal-day-cell other-month">${i}</div>`;
  }

  daysGrid.innerHTML = gridHtml;

  // Day cell click events
  daysGrid.querySelectorAll(".cal-day-cell[data-date]").forEach((cell) => {
    cell.addEventListener("click", () => {
      calSelectedDate = cell.getAttribute("data-date");
      renderStudyCalendar();
      updateCalendarSelectedDateSummary();
    });
  });

  updateCalendarSelectedDateSummary();
}

function updateCalendarSelectedDateSummary() {
  const labelEl = document.getElementById("calendar-selected-date-label");
  const timeEl = document.getElementById("calendar-selected-study-time");
  if (!labelEl || !timeEl) return;

  const data = getData();
  const historyList = data.history || [];

  const sessionsOnDate = historyList.filter(
    (h) => h.type === "study" && h.date === calSelectedDate,
  );
  const totalSeconds = sessionsOnDate.reduce((acc, curr) => acc + (curr.duration || 0), 0);
  const minutes = Math.round(totalSeconds / 60);

  const todayStr = new Date().toISOString().split("T")[0];
  const dateFormatted = calSelectedDate === todayStr ? "Today" : calSelectedDate;

  labelEl.textContent = `${dateFormatted} (${sessionsOnDate.length} session${sessionsOnDate.length === 1 ? "" : "s"}):`;

  if (minutes >= 60) {
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    timeEl.textContent = `${h}h ${m}m focus`;
  } else {
    timeEl.textContent = `${minutes}m focus`;
  }
}

export function updateStudyMetrics() {
  const data = getData();
  const streak = data.studyState?.currentStreak || 0;
  const streakText = document.getElementById("study-streak-text");
  if (streakText) {
    streakText.textContent = `${streak} Day Streak`;
  }

  const streakCount = document.getElementById("study-streak-count");
  if (streakCount) {
    streakCount.textContent = `${streak}d`;
  }

  // Calculate today's studied minutes
  const todayStr = new Date().toISOString().split("T")[0];
  const todaySessions = (data.history || []).filter(
    (h) => h.type === "study" && h.date === todayStr,
  );
  const totalSecondsToday = todaySessions.reduce((acc, curr) => acc + (curr.duration || 0), 0);
  const todayMinutes = Math.round(totalSecondsToday / 60);

  const todayMinEl = document.getElementById("study-today-minutes");
  if (todayMinEl) {
    if (todayMinutes >= 60) {
      const h = Math.floor(todayMinutes / 60);
      const m = todayMinutes % 60;
      todayMinEl.textContent = `${h}h ${m}m`;
    } else {
      todayMinEl.textContent = `${todayMinutes}m`;
    }
  }

  const allCompletedSessions = (data.history || []).filter(
    (h) => h.type === "study" && h.status === "completed",
  ).length;
  const allCountEl = document.getElementById("study-all-sessions-count");
  if (allCountEl) {
    allCountEl.textContent = `${allCompletedSessions}`;
  }
}

// ==========================================
// Web Audio API Ambient Sound (Pure Vanilla)
// ==========================================
function getAudioContext() {
  if (!audioCtx) {
    const AudioContextClass = window.AudioContext || window.webkitAudioContext;
    if (AudioContextClass) audioCtx = new AudioContextClass();
  }
  if (audioCtx && audioCtx.state === "suspended") {
    audioCtx.resume();
  }
  return audioCtx;
}

function startWhiteNoise() {
  stopAmbientSound();
  const ctx = getAudioContext();
  if (!ctx) return;

  const bufferSize = 2 * ctx.sampleRate;
  const noiseBuffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
  const output = noiseBuffer.getChannelData(0);
  let b0 = 0, b1 = 0, b2 = 0;

  // Pink noise filter for pleasant calm ambient wash
  for (let i = 0; i < bufferSize; i++) {
    const white = Math.random() * 2 - 1;
    b0 = 0.99886 * b0 + white * 0.0555179;
    b1 = 0.99332 * b1 + white * 0.0750759;
    b2 = 0.96900 * b2 + white * 0.153852;
    output[i] = (b0 + b1 + b2) * 0.04;
  }

  ambientSource = ctx.createBufferSource();
  ambientSource.buffer = noiseBuffer;
  ambientSource.loop = true;

  ambientGain = ctx.createGain();
  ambientGain.gain.setValueAtTime(0.08, ctx.currentTime);

  ambientSource.connect(ambientGain);
  ambientGain.connect(ctx.destination);
  ambientSource.start(0);
}

function stopAmbientSound() {
  if (ambientSource) {
    try {
      ambientSource.stop();
      ambientSource.disconnect();
    } catch {
      // Ignored
    }
    ambientSource = null;
  }
}

function toggleAmbientSound() {
  isSoundPlaying = !isSoundPlaying;
  const label = document.getElementById("ambient-sound-label");
  const btn = document.getElementById("btn-study-ambient-sound");

  if (isSoundPlaying) {
    if (activeStudy && (activeStudy.status === "studying" || activeStudy.status === "break")) {
      startWhiteNoise();
    }
    if (label) label.textContent = "Sound ON";
    if (btn) btn.setAttribute("data-active", "true");
  } else {
    stopAmbientSound();
    if (label) label.textContent = "Sound OFF";
    if (btn) btn.removeAttribute("data-active");
  }
}

function playChime() {
  const ctx = getAudioContext();
  if (!ctx) return;

  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = "sine";
  osc.frequency.setValueAtTime(587.33, ctx.currentTime); // D5
  osc.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.3); // A5

  gain.gain.setValueAtTime(0.15, ctx.currentTime);
  gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 1.2);

  osc.connect(gain);
  gain.connect(ctx.destination);
  osc.start();
  osc.stop(ctx.currentTime + 1.2);
}

// Fullscreen Focus Mode for Study
function toggleFullscreenStudy() {
  isFullscreenStudy = !isFullscreenStudy;
  const body = document.body;
  if (isFullscreenStudy) {
    body.classList.add("study-fullscreen-active");
    if (!document.getElementById("btn-study-exit-fs")) {
      const exitBtn = document.createElement("button");
      exitBtn.id = "btn-study-exit-fs";
      exitBtn.className = "study-fullscreen-exit-btn";
      exitBtn.innerHTML = `
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 14px; height: 14px;">
          <line x1="18" y1="6" x2="6" y2="18"/>
          <line x1="6" y1="6" x2="18" y2="18"/>
        </svg>
        <span>Exit Focus</span>
      `;
      exitBtn.addEventListener("click", exitFullscreenStudy);
      document.body.appendChild(exitBtn);
    }
  } else {
    exitFullscreenStudy();
  }
}

function exitFullscreenStudy() {
  isFullscreenStudy = false;
  document.body.classList.remove("study-fullscreen-active");
  const exitBtn = document.getElementById("btn-study-exit-fs");
  if (exitBtn) exitBtn.remove();
}

function escapeHtml(str) {
  if (!str) return "";
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
