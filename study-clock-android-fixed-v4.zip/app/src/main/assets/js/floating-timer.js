/**
 * floating-timer.js
 * Persistent Floating Study Timer Popup:
 * - Stays visible and interactive across all pages (Clock, Study, Timer, History, Settings).
 * - Frosted glass (smokey light/blur) minimal UI.
 * - Draggable on desktop, touch-draggable on mobile.
 * - Live study timer digits, start / pause / resume / stop actions.
 * - Timestamps-resilient (Date.now()) with automatic localStorage restoration.
 * - Minimizable into a small floating pill without stopping the timer.
 * - Shares active study session with study.js with zero duplication.
 */

import { getData } from "./storage.js";
import { pauseStudy, resumeStudy, endStudyEarly, applyNativeOverlayCommand } from "./study.js";

let floatingTimerInterval = null;
let isDragging = false;
let dragStartX = 0;
let dragStartY = 0;
let initialElemX = 0;
let initialElemY = 0;
let isMinimized = false;
let listenersInitialized = false;
let overlayPermissionPrompted = false;
let nativeCommandPoll = null;

function androidBridge() {
  return window.AndroidStudyOverlay && typeof window.AndroidStudyOverlay.syncTimer === "function"
    ? window.AndroidStudyOverlay
    : null;
}

function syncNativeOverlay(session) {
  const bridge = androidBridge();
  if (!bridge || !session) return;
  const isActive = session.status === "studying" || session.status === "paused" || session.status === "break";
  if (isActive && typeof bridge.hasOverlayPermission === "function" && !bridge.hasOverlayPermission()) {
    if (!overlayPermissionPrompted) {
      overlayPermissionPrompted = true;
      try { bridge.requestOverlayPermission(); } catch (_) {}
    }
    return;
  }
  if (!isActive) {
    try { bridge.stopTimer(); } catch (_) {}
    return;
  }
  const now = Date.now();
  const countdown = session.trackingMode === "countdown";
  let remaining = 0;
  if (session.status === "paused") {
    remaining = session.remainingSeconds || 0;
  } else if (countdown && session.endTimestamp) {
    remaining = Math.max(0, Math.ceil((session.endTimestamp - now) / 1000));
  } else if (session.startedAt) {
    remaining = Math.max(0, Math.floor((now - session.startedAt) / 1000));
  }
  const running = session.status === "studying" || session.status === "break";
  const label = session.taskName || (session.mode === "break" ? "Rest Break" : "Study Focus");
  try {
    bridge.syncTimer(
      remaining,
      running,
      session.status === "paused",
      label,
      countdown
    );
  } catch (_) {}
}

export function initFloatingTimer() {
  attachFloatingListeners();
  syncFloatingStateFromStorage();

  if (floatingTimerInterval) clearInterval(floatingTimerInterval);
  if (nativeCommandPoll) clearInterval(nativeCommandPoll);
  tickFloatingTimer();
  floatingTimerInterval = setInterval(tickFloatingTimer, 500);
  nativeCommandPoll = setInterval(pollNativeOverlayCommand, 200);
  pollNativeOverlayCommand();
}

function syncFloatingStateFromStorage() {
  const data = getData();
  const session = data.studyState?.activeSession;
  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  // Check saved minimize state
  const savedMin = localStorage.getItem("study_clock_floating_minimized") === "true";
  isMinimized = savedMin;
  applyMinimizeState();

  if (session && (session.status === "studying" || session.status === "paused" || session.status === "break")) {
    container.style.display = "block";
  } else {
    // If not active, hide floating timer
    container.style.display = "none";
  }
}

function pollNativeOverlayCommand() {
  const bridge = androidBridge();
  if (!bridge || typeof bridge.consumeOverlayCommand !== "function") return;

  try {
    const command = bridge.consumeOverlayCommand();
    if (!command) return;

    let state = "{}";
    if (typeof bridge.getOverlayState === "function") {
      state = bridge.getOverlayState() || "{}";
    }

    applyNativeOverlayCommand(command, state);
    tickFloatingTimer();
  } catch (_) {}
}

export function showFloatingTimer() {
  const container = document.getElementById("floating-study-timer");
  if (container) {
    container.style.display = "block";
    applyMinimizeState();
    tickFloatingTimer();
  }
}

export function hideFloatingTimer() {
  const container = document.getElementById("floating-study-timer");
  if (container) {
    container.style.display = "none";
  }
}

function applyMinimizeState() {
  const card = document.getElementById("floating-timer-card");
  const badge = document.getElementById("floating-minimized-badge");
  if (!card || !badge) return;

  if (isMinimized) {
    card.style.display = "none";
    badge.style.display = "flex";
  } else {
    card.style.display = "block";
    badge.style.display = "none";
  }
}

function attachFloatingListeners() {
  if (listenersInitialized) return;
  listenersInitialized = true;

  const container = document.getElementById("floating-study-timer");
  const dragHandle = document.getElementById("floating-timer-drag-handle");
  const minBadge = document.getElementById("floating-minimized-badge");
  const minBtn = document.getElementById("btn-floating-minimize");
  const closeBtn = document.getElementById("btn-floating-close");

  // Minimize button
  minBtn?.addEventListener("click", (e) => {
    e.stopPropagation();
    isMinimized = true;
    localStorage.setItem("study_clock_floating_minimized", "true");
    applyMinimizeState();
  });

  // Expand on badge click
  minBadge?.addEventListener("click", () => {
    isMinimized = false;
    localStorage.setItem("study_clock_floating_minimized", "false");
    applyMinimizeState();
  });

  // Close / Hide button (does NOT stop session)
  closeBtn?.addEventListener("click", (e) => {
    e.stopPropagation();
    hideFloatingTimer();
    const bridge = androidBridge();
    try { bridge?.hideOverlay(); } catch (_) {}
  });

  // Desktop Drag Support
  if (dragHandle && container) {
    dragHandle.addEventListener("mousedown", onMouseDown);
  }
  if (minBadge && container) {
    minBadge.addEventListener("mousedown", onMouseDown);
  }

  // Mobile Touch Drag Support
  if (dragHandle && container) {
    dragHandle.addEventListener("touchstart", onTouchStart, { passive: false });
  }
  if (minBadge && container) {
    minBadge.addEventListener("touchstart", onTouchStart, { passive: false });
  }

  window.addEventListener("resize", clampPositionToViewport);
}

function onMouseDown(e) {
  // Ignore clicks on control buttons
  if (e.target.closest("button")) return;

  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  isDragging = true;
  dragStartX = e.clientX;
  dragStartY = e.clientY;

  const rect = container.getBoundingClientRect();
  initialElemX = rect.left;
  initialElemY = rect.top;

  // Switch to fixed left/top coordinate model
  container.style.bottom = "auto";
  container.style.right = "auto";
  container.style.left = `${initialElemX}px`;
  container.style.top = `${initialElemY}px`;

  document.addEventListener("mousemove", onMouseMove);
  document.addEventListener("mouseup", onMouseUp);
  e.preventDefault();
}

function onMouseMove(e) {
  if (!isDragging) return;
  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  const dx = e.clientX - dragStartX;
  const dy = e.clientY - dragStartY;

  let newX = initialElemX + dx;
  let newY = initialElemY + dy;

  // Viewport bounds
  const maxX = window.innerWidth - container.offsetWidth - 8;
  const maxY = window.innerHeight - container.offsetHeight - 8;
  newX = Math.max(8, Math.min(newX, maxX));
  newY = Math.max(8, Math.min(newY, maxY));

  container.style.left = `${newX}px`;
  container.style.top = `${newY}px`;
}

function onMouseUp() {
  isDragging = false;
  document.removeEventListener("mousemove", onMouseMove);
  document.removeEventListener("mouseup", onMouseUp);
}

function onTouchStart(e) {
  if (e.target.closest("button")) return;
  const touch = e.touches[0];
  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  isDragging = true;
  dragStartX = touch.clientX;
  dragStartY = touch.clientY;

  const rect = container.getBoundingClientRect();
  initialElemX = rect.left;
  initialElemY = rect.top;

  container.style.bottom = "auto";
  container.style.right = "auto";
  container.style.left = `${initialElemX}px`;
  container.style.top = `${initialElemY}px`;

  document.addEventListener("touchmove", onTouchMove, { passive: false });
  document.addEventListener("touchend", onTouchEnd);
}

function onTouchMove(e) {
  if (!isDragging) return;
  e.preventDefault();
  const touch = e.touches[0];
  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  const dx = touch.clientX - dragStartX;
  const dy = touch.clientY - dragStartY;

  let newX = initialElemX + dx;
  let newY = initialElemY + dy;

  const maxX = window.innerWidth - container.offsetWidth - 8;
  const maxY = window.innerHeight - container.offsetHeight - 8;
  newX = Math.max(8, Math.min(newX, maxX));
  newY = Math.max(8, Math.min(newY, maxY));

  container.style.left = `${newX}px`;
  container.style.top = `${newY}px`;
}

function onTouchEnd() {
  isDragging = false;
  document.removeEventListener("touchmove", onTouchMove);
  document.removeEventListener("touchend", onTouchEnd);
}

function clampPositionToViewport() {
  const container = document.getElementById("floating-study-timer");
  if (!container || container.style.left === "") return;

  const rect = container.getBoundingClientRect();
  const maxX = window.innerWidth - rect.width - 8;
  const maxY = window.innerHeight - rect.height - 8;

  let left = Math.max(8, Math.min(rect.left, maxX));
  let top = Math.max(8, Math.min(rect.top, maxY));

  container.style.left = `${left}px`;
  container.style.top = `${top}px`;
}

export function tickFloatingTimer() {
  const container = document.getElementById("floating-study-timer");
  if (!container) return;

  const data = getData();
  const session = data.studyState?.activeSession;

  if (!session || (session.status !== "studying" && session.status !== "paused" && session.status !== "break")) {
    container.style.display = "none";
    return;
  }

  // Active session exists!
  container.style.display = "block";

  const now = Date.now();
  const isCountdown = session.trackingMode === "countdown";
  let displaySeconds = 0;
  let progressPct = 0;

  if (session.status === "studying" || session.status === "break") {
    if (isCountdown) {
      if (session.endTimestamp) {
        const remaining = Math.max(0, Math.ceil((session.endTimestamp - now) / 1000));
        displaySeconds = remaining;
        const planned = session.plannedDurationSeconds || 1500;
        progressPct = Math.min(100, Math.max(0, ((planned - remaining) / planned) * 100));
      }
    } else {
      // Count-up mode
      if (session.startedAt) {
        const elapsed = Math.max(0, Math.floor((now - session.startedAt) / 1000));
        displaySeconds = elapsed;
        progressPct = Math.min(100, ((elapsed % 3600) / 3600) * 100);
      }
    }
  } else if (session.status === "paused") {
    if (isCountdown) {
      displaySeconds = session.remainingSeconds || 0;
      const planned = session.plannedDurationSeconds || 1500;
      progressPct = Math.min(100, Math.max(0, ((planned - displaySeconds) / planned) * 100));
    } else {
      displaySeconds = session.elapsedSeconds || 0;
      progressPct = Math.min(100, ((displaySeconds % 3600) / 3600) * 100);
    }
  }

  const digitsFormatted = formatFloatingTime(displaySeconds, !isCountdown);

  // Update DOM elements
  const digitsEl = document.getElementById("floating-timer-digits");
  if (digitsEl) digitsEl.textContent = digitsFormatted;

  const badgeDigitsEl = document.getElementById("floating-badge-digits");
  if (badgeDigitsEl) badgeDigitsEl.textContent = digitsFormatted;

  const progressBar = document.getElementById("floating-progress-bar");
  if (progressBar) progressBar.style.width = `${progressPct}%`;

  const statusDot = document.getElementById("floating-status-dot");
  if (statusDot) {
    statusDot.className = `floating-pulse-dot ${session.status === "paused" ? "paused" : "active"}`;
  }

  const taskLabel = document.getElementById("floating-task-label");
  if (taskLabel) {
    taskLabel.textContent = session.taskName || (session.mode === "break" ? "Rest Break" : "Study Focus");
  }

  const studyTimeText = document.getElementById("floating-study-time-text");
  if (studyTimeText) {
    const totalMin = Math.round(displaySeconds / 60);
    studyTimeText.textContent = isCountdown ? `Remaining: ${totalMin}m` : `Studied: ${totalMin}m`;
  }

  const modeTag = document.getElementById("floating-mode-tag");
  if (modeTag) {
    modeTag.textContent = session.mode === "break" ? "Break" : (isCountdown ? "Countdown" : "Stopwatch");
  }

  // Keep Android system-wide overlay synchronized with the same session.
  syncNativeOverlay(session);

  // Update controls
  renderFloatingControls(session);
}

function renderFloatingControls(session) {
  const controlsRow = document.getElementById("floating-controls");
  if (!controlsRow) return;

  if (session.status === "studying" || session.status === "break") {
    controlsRow.innerHTML = `
      <button type="button" class="btn btn-secondary btn-sm" id="btn-fl-pause" title="Pause session">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="fl-btn-icon"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
        <span>Pause</span>
      </button>
      <button type="button" class="btn btn-danger btn-sm" id="btn-fl-end" title="End and record session">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="fl-btn-icon"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        <span>End</span>
      </button>
    `;
    document.getElementById("btn-fl-pause")?.addEventListener("click", () => {
      pauseStudy();
      tickFloatingTimer();
    });
    document.getElementById("btn-fl-end")?.addEventListener("click", () => {
      endStudyEarly();
      tickFloatingTimer();
    });
  } else if (session.status === "paused") {
    controlsRow.innerHTML = `
      <button type="button" class="btn btn-primary btn-sm" id="btn-fl-resume" title="Resume session">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="fl-btn-icon"><polygon points="5 3 19 12 5 21 5 3"/></svg>
        <span>Resume</span>
      </button>
      <button type="button" class="btn btn-danger btn-sm" id="btn-fl-end" title="End and record session">
        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="fl-btn-icon"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>
        <span>End</span>
      </button>
    `;
    document.getElementById("btn-fl-resume")?.addEventListener("click", () => {
      resumeStudy();
      tickFloatingTimer();
    });
    document.getElementById("btn-fl-end")?.addEventListener("click", () => {
      endStudyEarly();
      tickFloatingTimer();
    });
  }
}

function formatFloatingTime(totalSeconds = 0, forceHours = false) {
  const s = Math.max(0, Math.floor(totalSeconds));
  const hrs = Math.floor(s / 3600);
  const mins = Math.floor((s % 3600) / 60);
  const secs = s % 60;

  if (forceHours || hrs > 0) {
    return `${String(hrs).padStart(2, "0")}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
  }
  return `${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`;
}
