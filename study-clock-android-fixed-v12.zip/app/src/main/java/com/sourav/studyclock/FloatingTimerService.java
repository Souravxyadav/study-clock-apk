package com.sourav.studyclock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

public class FloatingTimerService extends Service {
    public static final String ACTION_SHOW = "SHOW";
    public static final String ACTION_CLOSE = "CLOSE";
    public static final String ACTION_START = "START";
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_RESUME = "RESUME";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_SYNC = "SYNC";

    private static final String PREF = "floating_timer";
    private static final String CHANNEL = "study_clock_overlay";
    private static final String COMMAND_KEY = "overlay_command";
    private static final String TEMPLATE_KEY = "template_index";
    private static final long DEFAULT_SECONDS = 25 * 60L;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private FrameLayout root;
    private LinearLayout expanded;
    private LinearLayout mini;
    private TextView timerText;
    private TextView miniTimerText;
    private TextView statusText;
    private TextView titleText;
    private Button actionButton;
    private Button finishButton;
    private Handler handler;
    private boolean attached;
    private boolean running;
    private boolean paused;
    private boolean countdownMode = true;
    private boolean minimized;
    private long remaining = DEFAULT_SECONDS;
    private long endAt;
    private long countUpStartedAt;
    private String label = "Study Focus";
    private static FloatingTimerService instance;

    private float downX, downY;
    private int startX, startY;
    private long lastTapAt;
    private boolean moved;

    // Eight structurally different overlay templates. Colors are only one part of the design.
    private static final int[][] TEMPLATES = {
            {0xFFFDFDFD, 0xFFF3F4F6, 0xFFE4573D, 0}, // Classic
            {0xFF111318, 0xFF111318, 0xFFFF7043, 1}, // Minimal
            {0xFFEFF8FF, 0xFFE2F2FF, 0xFF1683D8, 2}, // Split
            {0xFF101722, 0xFF172235, 0xFF4EA1FF, 3}, // Pill
            {0xFFF7F3FF, 0xFFEDE5FF, 0xFF7C4DFF, 4}, // Big Timer
            {0xFFEFFBF5, 0xFFE1F5EA, 0xFF169C62, 5}, // Focus Bar
            {0xFFFFF8EA, 0xFFFFF0D0, 0xFFD98600, 6}, // Dashboard
            {0xFFF4F5F7, 0xFFE7E9ED, 0xFF5D6674, 7}, // Edge
    };

    public static boolean isRunning() { return instance != null; }

    public static void updateFromWeb(long seconds, boolean webRunning, boolean webPaused,
                                     String webLabel, boolean countdown) {
        FloatingTimerService service = instance;
        if (service == null) return;
        service.handler.post(() -> service.applyWebState(seconds, webRunning, webPaused,
                webLabel, countdown));
    }

    public static String consumeOverlayCommand(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        String command = p.getString(COMMAND_KEY, "");
        if (command == null || command.isEmpty()) return "";
        p.edit().remove(COMMAND_KEY).apply();
        return command;
    }

    public static String getOverlayState(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        JSONObject o = new JSONObject();
        try {
            o.put("seconds", p.getLong("remaining", DEFAULT_SECONDS));
            o.put("running", p.getBoolean("running", false));
            o.put("paused", p.getBoolean("paused", false));
            o.put("countdown", p.getBoolean("countdownMode", true));
            o.put("label", p.getString("label", "Study Focus"));
        } catch (Exception ignored) {}
        return o.toString();
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        handler = new Handler(getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForegroundCompat();
        loadState();
        if (Settings.canDrawOverlays(this)) createOverlay();
        tick();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (action == null) action = ACTION_SHOW;
        switch (action) {
            case ACTION_START: startTimer(); break;
            case ACTION_PAUSE: pauseTimer(true); break;
            case ACTION_RESUME: resumeTimer(true); break;
            case ACTION_STOP: stopTimer(true); break;
            case ACTION_SYNC: syncFromWeb(intent); break;
            case ACTION_CLOSE: closeOverlay(); break;
            default:
                if (Settings.canDrawOverlays(this) && root == null) createOverlay();
                else showOverlay();
                break;
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("Study Clock")
                .setContentText("Study Focus timer is active")
                .setSmallIcon(com.sourav.studyclock.R.drawable.ic_study_clock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else startForeground(1001, n);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Study Clock Floating Timer", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Floating Study Focus timer");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, float radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void createOverlay() {
        if (!Settings.canDrawOverlays(this) || root != null) return;

        root = new FrameLayout(this);
        root.setPadding(0, 0, 0, 0);
        root.setBackgroundColor(Color.TRANSPARENT);

        expanded = buildExpandedCard();
        mini = buildMiniCard();
        int templateIndex = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        templateIndex = Math.max(0, Math.min(templateIndex, TEMPLATES.length - 1));
        int expandedHeight = (templateIndex == 3 || templateIndex == 5 || templateIndex == 7) ? dp(70) : dp(178);
        root.addView(expanded, new FrameLayout.LayoutParams(dp(316), expandedHeight));
        FrameLayout.LayoutParams miniLp = new FrameLayout.LayoutParams(dp(174), dp(54));
        miniLp.gravity = Gravity.CENTER;
        root.addView(mini, miniLp);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        params = new WindowManager.LayoutParams(
                dp(316), expandedHeight,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(18); params.y = dp(120);
        attachDrag(root);
        applyTemplate();
        showOverlay();
    }

    private LinearLayout buildExpandedCard() {
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = Math.max(0, Math.min(idx, TEMPLATES.length - 1));
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(9), dp(12), dp(10));
        card.setElevation(dp(12));

        if (idx == 3) return buildPillCard(card);
        if (idx == 5) return buildFocusBar(card);
        if (idx == 2) return buildSplitCard(card);
        if (idx == 4) return buildBigTimerCard(card);
        if (idx == 6) return buildDashboardCard(card);
        if (idx == 7) return buildEdgeCard(card);
        if (idx == 1) return buildMinimalCard(card);
        return buildClassicCard(card);
    }

    private LinearLayout header(boolean showStatus, boolean showLogo) {
        LinearLayout h = new LinearLayout(this);
        h.setGravity(Gravity.CENTER_VERTICAL);
        if (showLogo) {
            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.ic_study_clock);
            logo.setPadding(dp(2), dp(2), dp(2), dp(2));
            h.addView(logo, new LinearLayout.LayoutParams(dp(28), dp(28)));
        }
        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        titleWrap.setPadding(dp(7), 0, dp(3), 0);
        titleText = text("Study Focus", 15, Color.DKGRAY);
        titleText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleWrap.addView(titleText);
        statusText = text(showStatus ? "Studying" : "", 10, Color.GRAY);
        if (showStatus) titleWrap.addView(statusText);
        h.addView(titleWrap, new LinearLayout.LayoutParams(0, dp(42), 1));
        Button close = button("×");
        close.setTextSize(20);
        close.setOnClickListener(v -> closeOverlay());
        h.addView(close, new LinearLayout.LayoutParams(dp(38), dp(40)));
        return h;
    }

    private LinearLayout controls(boolean compact) {
        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        actionButton = button("Pause");
        finishButton = button("Finish");
        actionButton.setOnClickListener(v -> { if (running) pauseTimer(true); else if (paused) resumeTimer(true); });
        finishButton.setOnClickListener(v -> stopTimer(true));
        int h = compact ? 36 : 42;
        controls.addView(actionButton, new LinearLayout.LayoutParams(0, dp(h), 1));
        controls.addView(finishButton, new LinearLayout.LayoutParams(0, dp(h), 1));
        return controls;
    }

    private LinearLayout buildClassicCard(LinearLayout card) {
        LinearLayout h = header(true, true);
        card.addView(h);
        timerText = text(format(remaining), 30, Color.rgb(30,30,34));
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, dp(62)));
        card.addView(controls(false));
        return card;
    }

    private LinearLayout buildMinimalCard(LinearLayout card) {
        card.setPadding(dp(8), dp(6), dp(8), dp(7));
        LinearLayout h = header(false, false);
        card.addView(h, new LinearLayout.LayoutParams(-1, dp(34)));
        timerText = text(format(remaining), 34, Color.WHITE);
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, dp(76)));
        card.addView(controls(true));
        return card;
    }

    private LinearLayout buildSplitCard(LinearLayout card) {
        LinearLayout h = header(false, true);
        card.addView(h, new LinearLayout.LayoutParams(-1, dp(40)));
        LinearLayout body = new LinearLayout(this);
        body.setGravity(Gravity.CENTER_VERTICAL);
        timerText = text(format(remaining), 29, Color.rgb(30,30,34));
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        body.addView(timerText, new LinearLayout.LayoutParams(0, dp(82), 1));
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.CENTER);
        actionButton = button("Pause");
        finishButton = button("Finish");
        actionButton.setOnClickListener(v -> { if (running) pauseTimer(true); else if (paused) resumeTimer(true); });
        finishButton.setOnClickListener(v -> stopTimer(true));
        right.addView(actionButton, new LinearLayout.LayoutParams(dp(110), dp(36)));
        right.addView(finishButton, new LinearLayout.LayoutParams(dp(110), dp(36)));
        body.addView(right, new LinearLayout.LayoutParams(dp(118), dp(82)));
        card.addView(body, new LinearLayout.LayoutParams(-1, dp(88)));
        return card;
    }

    private LinearLayout buildPillCard(LinearLayout card) {
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(10), 0, dp(8), 0);
        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_study_clock);
        card.addView(logo, new LinearLayout.LayoutParams(dp(28), dp(28)));
        timerText = text(formatShort(remaining), 20, Color.WHITE);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        card.addView(timerText, new LinearLayout.LayoutParams(0, dp(52), 1));
        actionButton = button("Pause");
        finishButton = button("End");
        actionButton.setOnClickListener(v -> { if (running) pauseTimer(true); else if (paused) resumeTimer(true); });
        finishButton.setOnClickListener(v -> stopTimer(true));
        card.addView(actionButton, new LinearLayout.LayoutParams(dp(70), dp(40)));
        card.addView(finishButton, new LinearLayout.LayoutParams(dp(62), dp(40)));
        titleText = text("Study Focus", 1, Color.TRANSPARENT);
        statusText = text("", 1, Color.TRANSPARENT);
        return card;
    }

    private LinearLayout buildBigTimerCard(LinearLayout card) {
        LinearLayout h = header(false, true);
        card.addView(h, new LinearLayout.LayoutParams(-1, dp(40)));
        timerText = text(format(remaining), 40, Color.rgb(40,20,70));
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, dp(78)));
        card.addView(controls(true));
        return card;
    }

    private LinearLayout buildFocusBar(LinearLayout card) {
        card.setPadding(dp(12), dp(7), dp(12), dp(7));
        LinearLayout h = header(false, true);
        card.addView(h, new LinearLayout.LayoutParams(-1, dp(34)));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        timerText = text(formatShort(remaining), 24, Color.rgb(20,90,55));
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        row.addView(timerText, new LinearLayout.LayoutParams(0, dp(48), 1));
        LinearLayout c = controls(true);
        row.addView(c, new LinearLayout.LayoutParams(dp(150), dp(48)));
        card.addView(row, new LinearLayout.LayoutParams(-1, dp(52)));
        return card;
    }

    private LinearLayout buildDashboardCard(LinearLayout card) {
        LinearLayout h = header(true, true);
        card.addView(h, new LinearLayout.LayoutParams(-1, dp(42)));
        LinearLayout panel = new LinearLayout(this);
        panel.setGravity(Gravity.CENTER_VERTICAL);
        timerText = text(format(remaining), 27, Color.rgb(120,80,0));
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(timerText, new LinearLayout.LayoutParams(0, dp(58), 1));
        TextView badge = text("FOCUS", 10, Color.GRAY);
        badge.setGravity(Gravity.CENTER);
        panel.addView(badge, new LinearLayout.LayoutParams(dp(60), dp(40)));
        card.addView(panel, new LinearLayout.LayoutParams(-1, dp(60)));
        card.addView(controls(true));
        return card;
    }

    private LinearLayout buildEdgeCard(LinearLayout card) {
        card.setPadding(dp(10), dp(5), dp(10), dp(6));
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        timerText = text(formatShort(remaining), 25, Color.rgb(70,75,85));
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        row.addView(timerText, new LinearLayout.LayoutParams(0, dp(50), 1));
        actionButton = button("Pause");
        finishButton = button("×");
        actionButton.setOnClickListener(v -> { if (running) pauseTimer(true); else if (paused) resumeTimer(true); });
        finishButton.setOnClickListener(v -> stopTimer(true));
        row.addView(actionButton, new LinearLayout.LayoutParams(dp(76), dp(38)));
        row.addView(finishButton, new LinearLayout.LayoutParams(dp(42), dp(38)));
        card.addView(row);
        titleText = text("Study Focus", 1, Color.TRANSPARENT);
        statusText = text("", 1, Color.TRANSPARENT);
        return card;
    }

    private LinearLayout buildMiniCard() {
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(10), 0, dp(8), 0);
        pill.setElevation(dp(12));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_study_clock);
        pill.addView(logo, new LinearLayout.LayoutParams(dp(26), dp(26)));
        miniTimerText = text("00:00", 15, Color.DKGRAY);
        miniTimerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        miniTimerText.setGravity(Gravity.CENTER);
        pill.addView(miniTimerText, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button expand = button("⌃");
        expand.setTextSize(16);
        expand.setOnClickListener(v -> setMinimized(false));
        pill.addView(expand, new LinearLayout.LayoutParams(dp(38), dp(40)));
        pill.setOnClickListener(v -> setMinimized(false));
        return pill;
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX(); downY = event.getRawY();
                    startX = params.x; startY = params.y; moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downX, dy = event.getRawY() - downY;
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                    if (attached && moved) {
                        params.x = startX + (int) dx; params.y = startY + (int) dy;
                        clampPosition(); wm.updateViewLayout(root, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        long now = System.currentTimeMillis();
                        if (now - lastTapAt < 320) { openApp(); lastTapAt = 0; }
                        else lastTapAt = now;
                    }
                    return true;
            }
            return true;
        });
    }

    private int currentExpandedHeight() {
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = Math.max(0, Math.min(idx, TEMPLATES.length - 1));
        return (idx == 3 || idx == 5 || idx == 7) ? dp(70) : dp(178);
    }

    private void clampPosition() {
        if (wm == null || root == null) return;
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int w = minimized ? dp(174) : dp(316);
        int h = minimized ? dp(54) : currentExpandedHeight();
        params.x = Math.max(dp(8), Math.min(params.x, width - w - dp(8)));
        params.y = Math.max(dp(8), Math.min(params.y, height - h - dp(8)));
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private void setMinimized(boolean value) {
        minimized = value;
        if (expanded != null) expanded.setVisibility(value ? View.GONE : View.VISIBLE);
        if (mini != null) mini.setVisibility(value ? View.VISIBLE : View.GONE);
        if (root != null && attached) {
            params.width = value ? dp(174) : dp(316);
            params.height = value ? dp(54) : currentExpandedHeight();
            clampPosition();
            try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
        }
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean("minimized", value).apply();
    }

    private void showOverlay() {
        if (root == null || !Settings.canDrawOverlays(this)) return;
        if (!attached) {
            try { wm.addView(root, params); attached = true; } catch (Exception ignored) { return; }
        }
        root.setVisibility(View.VISIBLE);
        setMinimized(minimized);
        updateControls();
    }

    private void closeOverlay() {
        if (attached && root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            attached = false;
        }
        saveState();
    }

    private void syncFromWeb(Intent intent) {
        if (intent == null) return;
        applyWebState(
                Math.max(0L, intent.getLongExtra("remainingSeconds", remaining)),
                intent.getBooleanExtra("running", false),
                intent.getBooleanExtra("paused", false),
                intent.getStringExtra("label"),
                intent.getBooleanExtra("countdown", true));
    }

    private void applyWebState(long seconds, boolean webRunning, boolean webPaused, String webLabel, boolean countdown) {
        countdownMode = countdown;
        remaining = Math.max(0L, seconds);
        running = webRunning;
        paused = webPaused;
        label = (webLabel == null || webLabel.trim().isEmpty()) ? "Study Focus" : webLabel;
        long now = System.currentTimeMillis();
        if (countdownMode) { endAt = running ? now + remaining * 1000L : 0L; countUpStartedAt = 0L; }
        else { countUpStartedAt = running ? now - remaining * 1000L : 0L; endAt = 0L; }
        saveState();
        if (running || paused) showOverlay();
        else closeOverlay();
        updateControls();
    }

    private void startTimer() {
        if (remaining <= 0) remaining = DEFAULT_SECONDS;
        paused = false; running = true;
        if (countdownMode) endAt = System.currentTimeMillis() + remaining * 1000L;
        else countUpStartedAt = System.currentTimeMillis() - remaining * 1000L;
        queueCommand("start"); saveState(); updateControls(); showOverlay();
    }

    private void pauseTimer(boolean fromOverlay) {
        if (!running) return;
        long now = System.currentTimeMillis();
        if (countdownMode) remaining = Math.max(0L, (endAt - now + 999L) / 1000L);
        else if (countUpStartedAt > 0) remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
        running = false; paused = true; endAt = 0L;
        if (fromOverlay) queueCommand("pause");
        saveState(); updateControls(); showOverlay();
    }

    private void resumeTimer(boolean fromOverlay) {
        if (!paused) return;
        long now = System.currentTimeMillis();
        if (countdownMode) endAt = now + remaining * 1000L;
        else countUpStartedAt = now - remaining * 1000L;
        running = true; paused = false;
        if (fromOverlay) queueCommand("resume");
        saveState(); updateControls(); showOverlay();
    }

    private void stopTimer(boolean fromOverlay) {
        running = false; paused = false; endAt = 0L; countUpStartedAt = 0L; remaining = 0L;
        if (fromOverlay) queueCommand("finish");
        saveState(); updateControls(); closeOverlay(); stopSelf();
    }

    private void queueCommand(String command) {
        // One queued command is consumed by the WebView and then calls the exact Study-page action.
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(COMMAND_KEY, command).apply();
    }

    private void updateControls() {
        if (titleText != null) titleText.setText(label);
        if (statusText != null) statusText.setText(running ? "Studying" : paused ? "Paused" : "Study Focus");
        if (actionButton != null) {
            actionButton.setText(running ? "Pause" : paused ? "Resume" : "Pause");
            actionButton.setEnabled(running || paused);
        }
        if (finishButton != null) finishButton.setEnabled(running || paused);
        if (timerText != null) timerText.setText(format(remaining));
        if (miniTimerText != null) miniTimerText.setText(formatShort(remaining));
    }

    public static void setTemplate(Context context, int index) {
        int safe = Math.max(0, Math.min(index, TEMPLATES.length - 1));
        context.getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt(TEMPLATE_KEY, safe).apply();
        FloatingTimerService service = instance;
        if (service != null) service.handler.post(service::rebuildOverlayForTemplate);
    }

    private void rebuildOverlayForTemplate() {
        if (root == null) return;
        boolean wasAttached = attached;
        if (wasAttached) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            attached = false;
        }
        int oldMin = minimized ? 1 : 0;
        root.removeAllViews();
        expanded = buildExpandedCard();
        mini = buildMiniCard();
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = Math.max(0, Math.min(idx, TEMPLATES.length - 1));
        int w = (idx == 3 || idx == 5 || idx == 7) ? dp(316) : dp(316);
        int h = (idx == 3 || idx == 5 || idx == 7) ? dp(70) : dp(178);
        root.addView(expanded, new FrameLayout.LayoutParams(w, h));
        FrameLayout.LayoutParams miniLp = new FrameLayout.LayoutParams(dp(174), dp(54));
        miniLp.gravity = Gravity.CENTER;
        root.addView(mini, miniLp);
        params.width = minimized ? dp(174) : w;
        params.height = minimized ? dp(54) : h;
        attachDrag(root);
        applyTemplate();
        if (oldMin == 1) setMinimized(true); else if (wasAttached) showOverlay();
    }

    private void applyTemplate() {
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = Math.max(0, Math.min(idx, TEMPLATES.length - 1));
        int bgColor = TEMPLATES[idx][0], headerColor = TEMPLATES[idx][1], accent = TEMPLATES[idx][2];
        if (expanded != null) {
            expanded.setBackground(bg(bgColor, idx == 3 ? 28 : 20, 0x33909090));
            if (expanded.getChildCount() > 0 && idx != 3 && idx != 7) expanded.getChildAt(0).setBackground(bg(headerColor, 16, 0x22909090));
        }
        if (mini != null) mini.setBackground(bg(headerColor, 27, 0x33909090));
        if (timerText != null) timerText.setTextColor(idx == 1 || idx == 3 ? Color.WHITE : accent);
        if (actionButton != null) actionButton.setTextColor(accent);
        if (finishButton != null) finishButton.setTextColor(accent);
        updateControls();
    }

    private void tick() {
        if (running) {
            long now = System.currentTimeMillis();
            if (countdownMode) {
                remaining = Math.max(0L, (endAt - now + 999L) / 1000L);
                if (remaining == 0L) {
                    running = false; paused = false;
                    queueCommand("complete"); saveState(); closeOverlay(); stopSelf();
                    return;
                }
            } else if (countUpStartedAt > 0) remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
            updateControls(); saveState();
        }
        handler.postDelayed(this::tick, 500);
    }

    private String format(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }

    private String formatShort(long seconds) {
        long m = seconds / 60, s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    private void loadState() {
        android.content.SharedPreferences p = getSharedPreferences(PREF, MODE_PRIVATE);
        remaining = p.getLong("remaining", DEFAULT_SECONDS); endAt = p.getLong("endAt", 0L);
        running = p.getBoolean("running", false); paused = p.getBoolean("paused", false);
        countdownMode = p.getBoolean("countdownMode", true); countUpStartedAt = p.getLong("countUpStartedAt", 0L);
        label = p.getString("label", "Study Focus"); minimized = p.getBoolean("minimized", false);
        if (running) {
            if (countdownMode && endAt > 0) remaining = Math.max(0L, (endAt - System.currentTimeMillis() + 999L) / 1000L);
            else if (!countdownMode && countUpStartedAt > 0) remaining = Math.max(0L, (System.currentTimeMillis() - countUpStartedAt) / 1000L);
        }
    }

    private void saveState() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putLong("remaining", remaining).putLong("endAt", endAt)
                .putBoolean("running", running).putBoolean("paused", paused)
                .putBoolean("countdownMode", countdownMode).putLong("countUpStartedAt", countUpStartedAt)
                .putString("label", label).apply();
    }

    @Override public void onDestroy() {
        if (attached && root != null) { try { wm.removeView(root); } catch (Exception ignored) {} }
        attached = false;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
