/**
 * storage.js
 * Central LocalStorage management for Study Clock
 */

const STORAGE_KEY = "studyClockData";
const LEGACY_STORAGE_KEY = "smokey_clock_app";

export const DEFAULT_DATA = {
  settings: {
    clock: {
      template: "flip", // 'flip', 'digital', 'large-digital', 'minimal-digital', etc.
      format: "12h", // '12h' | '24h'
      showSeconds: true,
      showDate: true,
      nightMode: false,
      chimeEnabled: false,
    },
    study: {
      defaultTemplate: "classic",
      defaultStudyMinutes: 25,
      defaultBreakMinutes: 5,
      autoStartBreak: false,
      autoStartNextSession: false,
      sessionsBeforeLongBreak: 4,
      dailyGoalMinutes: 120, // Daily Study Goal in minutes
    },
    timer: {
      defaultDurationSeconds: 1500, // 25 min
    },
    floating: {
      template: 0,
    },
    appearance: {
      density: "comfortable", // 'comfortable' | 'compact'
      accent: "coral", // 'coral' | 'amber' | 'emerald' | 'blue' | 'monochrome'
    },
  },
  studyState: {
    activeSession: null, // { id, template, type: 'study'|'break', plannedDuration, startedAt, endAt, pausedAt, remainingWhenPaused, status: 'ready'|'studying'|'paused'|'break'|'completed', taskName: string, notes: string, completedSessions: number, targetSessions: number, trackingMode: 'countup'|'countdown' }
    completedCountToday: 0,
    currentStreak: 0,
    lastCompletedDate: null,
    currentTask: "",
    notes: "",
    soundEnabled: false,
    soundType: "none", // 'none' | 'whitenoise' | 'rain' | 'binaural' | 'chime'
    trackingMode: "countup", // 'countup' (stopwatch/how much studied) | 'countdown' (target interval)
    subtasks: [
      { id: "st_1", text: "Read key concepts & chapter summary", completed: false },
      { id: "st_2", text: "Complete practice problem set", completed: false },
      { id: "st_3", text: "Self-test & revision notes", completed: false }
    ],
    routines: [
      { id: "morning", title: "Morning Deep Focus", time: "08:00 - 10:00", targetMin: 120, completed: false },
      { id: "afternoon", title: "Core Study & Practice", time: "14:00 - 16:30", targetMin: 150, completed: false },
      { id: "evening", title: "Evening Revision & Quiz", time: "19:00 - 20:30", targetMin: 90, completed: false }
    ],
    routineDate: null,
  },
  activeTimer: null, // { id, duration, remaining, startedAt, endAt, pausedAt, status: 'idle'|'running'|'paused'|'completed' }
  history: [], // [{ id, type: 'study'|'timer', template: string, task: string, date: 'YYYY-MM-DD', startTime: string, endTime: string, duration: number, status: 'completed'|'incomplete' }]
};

export function getData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        ...DEFAULT_DATA,
        ...parsed,
        studyState: {
          ...DEFAULT_DATA.studyState,
          ...(parsed.studyState || {}),
          subtasks: parsed.studyState?.subtasks !== undefined ? parsed.studyState.subtasks : DEFAULT_DATA.studyState.subtasks,
          routines: parsed.studyState?.routines !== undefined ? parsed.studyState.routines : DEFAULT_DATA.studyState.routines,
        },
        settings: {
          ...DEFAULT_DATA.settings,
          ...(parsed.settings || {}),
          clock: { ...DEFAULT_DATA.settings.clock, ...(parsed.settings?.clock || {}) },
          study: { ...DEFAULT_DATA.settings.study, ...(parsed.settings?.study || {}) },
          timer: { ...DEFAULT_DATA.settings.timer, ...(parsed.settings?.timer || {}) },
          floating: { ...DEFAULT_DATA.settings.floating, ...(parsed.settings?.floating || {}) },
          appearance: {
            ...DEFAULT_DATA.settings.appearance,
            ...(parsed.settings?.appearance || {}),
          },
        },
      };
    }

    // Attempt migration from legacy key if available
    const legacyRaw = localStorage.getItem(LEGACY_STORAGE_KEY);
    if (legacyRaw) {
      const legacy = JSON.parse(legacyRaw);
      const migrated = {
        ...DEFAULT_DATA,
        settings: {
          ...DEFAULT_DATA.settings,
          clock: {
            template: legacy.settings?.clockType === "flip" ? "flip" : "digital",
            format: legacy.settings?.timeFormat === "24" ? "24h" : "12h",
            showSeconds: legacy.settings?.seconds ?? true,
            showDate: legacy.settings?.showDate ?? true,
          },
        },
        history: Array.isArray(legacy.study?.sessions)
          ? legacy.study.sessions.map((s) => ({
              id: s.id,
              type: "study",
              template: "Study Session",
              date: s.date || new Date(s.startedAt).toISOString().split("T")[0],
              startTime: new Date(s.startedAt).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              }),
              endTime: s.endedAt
                ? new Date(s.endedAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
                : "",
              duration: s.activeSeconds || s.plannedSeconds || 1500,
              status: s.status === "completed" ? "completed" : "incomplete",
            }))
          : [],
      };
      saveData(migrated);
      return migrated;
    }
  } catch (err) {
    console.error("Error reading studyClockData:", err);
  }

  return JSON.parse(JSON.stringify(DEFAULT_DATA));
}

export function saveData(data) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    window.dispatchEvent(new CustomEvent("studyClockDataChanged", { detail: data }));
    return true;
  } catch (err) {
    console.error("Error saving studyClockData:", err);
    return false;
  }
}

export function updateData(partial) {
  const current = getData();
  const next = {
    ...current,
    ...partial,
    settings: {
      ...current.settings,
      ...(partial.settings || {}),
      clock: { ...current.settings.clock, ...(partial.settings?.clock || {}) },
      study: { ...current.settings.study, ...(partial.settings?.study || {}) },
      timer: { ...current.settings.timer, ...(partial.settings?.timer || {}) },
      appearance: { ...current.settings.appearance, ...(partial.settings?.appearance || {}) },
    },
  };
  saveData(next);
  return next;
}

export function resetData() {
  saveData(DEFAULT_DATA);
  return DEFAULT_DATA;
}

export function addHistory(item) {
  const current = getData();
  const todayStr = new Date().toISOString().split("T")[0];
  const entry = {
    id: item.id || `hist_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
    type: item.type || "study", // 'study' | 'timer'
    template: item.template || "Standard",
    task: item.task || "",
    date: item.date || todayStr,
    startTime:
      item.startTime || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    endTime:
      item.endTime || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    duration: Math.round(item.duration || 0),
    status: item.status || "completed", // 'completed' | 'incomplete'
  };

  const nextHistory = [entry, ...(current.history || [])];

  // Update study streaks if completed study session
  let updatedStudyState = { ...(current.studyState || {}) };
  if (entry.type === "study" && entry.status === "completed") {
    const prevDate = updatedStudyState.lastCompletedDate;
    let streak = updatedStudyState.currentStreak || 0;
    if (!prevDate) {
      streak = 1;
    } else if (prevDate !== todayStr) {
      const yesterday = new Date();
      yesterday.setDate(yesterday.getDate() - 1);
      const yesterdayStr = yesterday.toISOString().split("T")[0];
      if (prevDate === yesterdayStr) {
        streak += 1;
      } else {
        streak = 1;
      }
    }
    const todayCount = (prevDate === todayStr ? (updatedStudyState.completedCountToday || 0) : 0) + 1;
    updatedStudyState = {
      ...updatedStudyState,
      completedCountToday: todayCount,
      currentStreak: streak,
      lastCompletedDate: todayStr,
    };
  }

  updateData({ history: nextHistory, studyState: updatedStudyState });
  return entry;
}

export function deleteHistoryItem(id) {
  const current = getData();
  const nextHistory = (current.history || []).filter((h) => h.id !== id);
  updateData({ history: nextHistory });
  return nextHistory;
}

export function clearHistory() {
  updateData({ history: [] });
  return [];
}

export function exportData() {
  const data = getData();
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `study-clock-backup-${new Date().toISOString().split("T")[0]}.json`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

export function importData(jsonString) {
  try {
    const parsed = typeof jsonString === "string" ? JSON.parse(jsonString) : jsonString;
    if (!parsed || typeof parsed !== "object") {
      throw new Error("Invalid format: Root must be an object");
    }
    const sanitized = {
      ...DEFAULT_DATA,
      ...parsed,
      settings: {
        ...DEFAULT_DATA.settings,
        ...(parsed.settings || {}),
        clock: { ...DEFAULT_DATA.settings.clock, ...(parsed.settings?.clock || {}) },
        study: { ...DEFAULT_DATA.settings.study, ...(parsed.settings?.study || {}) },
        timer: { ...DEFAULT_DATA.settings.timer, ...(parsed.settings?.timer || {}) },
        appearance: { ...DEFAULT_DATA.settings.appearance, ...(parsed.settings?.appearance || {}) },
      },
      history: Array.isArray(parsed.history) ? parsed.history : [],
    };
    saveData(sanitized);
    return { success: true };
  } catch (err) {
    return { success: false, error: err.message || "Failed to parse JSON" };
  }
}
