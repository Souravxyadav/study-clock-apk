/**
 * timer.js
 * Dedicated Countdown Timer Engine with Presets (5, 10, 15, 25, 30, 45, 50, 60, 90, 120m),
 * Custom H:M:S input, timestamp drift protection, progress indicator, and history saving.
 */

import { getData, updateData, addHistory } from "./storage.js";

export const TIMER_PRESETS = [
  { label: "5m", minutes: 5 },
  { label: "10m", minutes: 10 },
  { label: "15m", minutes: 15 },
  { label: "25m", minutes: 25 },
  { label: "30m", minutes: 30 },
  { label: "45m", minutes: 45 },
  { label: "50m", minutes: 50 },
  { label: "60m", minutes: 60 },
  { label: "90m", minutes: 90 },
  { label: "120m", minutes: 120 },
];

let timerInterval = null;
let activeTimer = null;
/*
activeTimer = {
  id: string,
  totalSeconds: number,
  remainingSeconds: number,
  status: 'idle' | 'running' | 'paused' | 'completed',
  startedAt: number,
  endTimestamp: number,
  pausedAt: number | null,
}
*/

export function initTimer() {
  const data = getData();
  const saved = data.activeTimer;

  if (saved && (saved.status === "running" || saved.status === "paused")) {
    restoreTimerState(saved);
  } else {
    const defaultSec = data.settings.timer?.defaultDurationSeconds || 1500;
    resetTimerState(defaultSec);
  }

  renderTimerPresets();
  renderTimerUI();

  const customForm = document.getElementById("timer-custom-form");
  if (customForm) {
    customForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const h = parseInt(document.getElementById("timer-custom-h")?.value || "0", 10) || 0;
      const m = parseInt(document.getElementById("timer-custom-m")?.value || "0", 10) || 0;
      const s = parseInt(document.getElementById("timer-custom-s")?.value || "0", 10) || 0;
      const totalSeconds = h * 3600 + m * 60 + s;
      if (totalSeconds > 0) {
        setTimerDuration(totalSeconds);
      }
    });
  }

  document.addEventListener("visibilitychange", handleTimerVisibilityChange);
}

function handleTimerVisibilityChange() {
  if (document.visibilityState === "visible" && activeTimer && activeTimer.status === "running") {
    tickTimer();
  }
}

function resetTimerState(durationSeconds = 1500) {
  activeTimer = {
    id: `timer_${Date.now()}`,
    totalSeconds: durationSeconds,
    remainingSeconds: durationSeconds,
    status: "idle",
    startedAt: null,
    endTimestamp: null,
    pausedAt: null,
  };
  saveTimerState();
}

function restoreTimerState(saved) {
  activeTimer = { ...saved };
  if (activeTimer.status === "running") {
    const now = Date.now();
    const remainingMs = activeTimer.endTimestamp - now;
    if (remainingMs <= 0) {
      completeTimer();
      return;
    } else {
      activeTimer.remainingSeconds = Math.max(0, Math.ceil(remainingMs / 1000));
      startTimerInterval();
    }
  }
}

function saveTimerState() {
  updateData({ activeTimer });
}

export function setTimerDuration(seconds) {
  if (activeTimer && (activeTimer.status === "running" || activeTimer.status === "paused")) {
    stopTimerInterval();
    recordTimerHistory("incomplete");
  }
  resetTimerState(seconds);
  renderTimerUI();
}

export function startTimer() {
  if (!activeTimer || activeTimer.remainingSeconds <= 0) return;

  const now = Date.now();
  activeTimer.startedAt = activeTimer.startedAt || now;
  activeTimer.status = "running";
  activeTimer.endTimestamp = now + activeTimer.remainingSeconds * 1000;
  activeTimer.pausedAt = null;

  saveTimerState();
  startTimerInterval();
  renderTimerUI();
}

export function pauseTimer() {
  if (!activeTimer || activeTimer.status !== "running") return;

  stopTimerInterval();
  const now = Date.now();
  activeTimer.pausedAt = now;
  activeTimer.remainingSeconds = Math.max(0, Math.ceil((activeTimer.endTimestamp - now) / 1000));
  activeTimer.status = "paused";

  saveTimerState();
  renderTimerUI();
}

export function resumeTimer() {
  if (!activeTimer || activeTimer.status !== "paused") return;

  const now = Date.now();
  activeTimer.endTimestamp = now + activeTimer.remainingSeconds * 1000;
  activeTimer.pausedAt = null;
  activeTimer.status = "running";

  saveTimerState();
  startTimerInterval();
  renderTimerUI();
}

export function resetTimer() {
  stopTimerInterval();
  if (activeTimer && activeTimer.status !== "idle" && activeTimer.status !== "completed") {
    recordTimerHistory("incomplete");
  }
  resetTimerState(activeTimer?.totalSeconds || 1500);
  renderTimerUI();
}

export function stopTimer() {
  if (!activeTimer) return;
  stopTimerInterval();
  if (activeTimer.status === "running" || activeTimer.status === "paused") {
    recordTimerHistory("incomplete");
  }
  resetTimerState(activeTimer.totalSeconds);
  renderTimerUI();
}

function startTimerInterval() {
  if (timerInterval) clearInterval(timerInterval);
  timerInterval = setInterval(tickTimer, 500);
}

function stopTimerInterval() {
  if (timerInterval) {
    clearInterval(timerInterval);
    timerInterval = null;
  }
}

function tickTimer() {
  if (!activeTimer || !activeTimer.endTimestamp) return;

  const now = Date.now();
  const diffMs = activeTimer.endTimestamp - now;

  if (diffMs <= 0) {
    completeTimer();
  } else {
    activeTimer.remainingSeconds = Math.max(0, Math.ceil(diffMs / 1000));
    updateTimerDigits();
  }
}

function completeTimer() {
  stopTimerInterval();
  activeTimer.remainingSeconds = 0;
  activeTimer.status = "completed";

  recordTimerHistory("completed");
  saveTimerState();
  renderTimerUI();
}

function recordTimerHistory(status) {
  if (!activeTimer || !activeTimer.startedAt) return;

  const planned = activeTimer.totalSeconds;
  const elapsed = Math.max(0, planned - activeTimer.remainingSeconds);
  const now = new Date();
  const start = new Date(activeTimer.startedAt);

  addHistory({
    type: "timer",
    template: `${Math.round(planned / 60)}m Timer`,
    date: start.toISOString().split("T")[0],
    startTime: start.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    endTime: now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    duration: status === "completed" ? planned : elapsed,
    status: status,
  });
}

function formatTimerDigits(totalSeconds) {
  const h = Math.floor(totalSeconds / 3600);
  const m = Math.floor((totalSeconds % 3600) / 60);
  const s = totalSeconds % 60;

  if (h > 0) {
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  return `${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}

export function renderTimerUI() {
  const digitsEl = document.getElementById("timer-digits-display");
  const progressFillEl = document.getElementById("timer-progress-fill");
  const statusEl = document.getElementById("timer-status-badge");
  const actionsEl = document.getElementById("timer-actions-container");

  if (!digitsEl || !activeTimer) return;

  digitsEl.textContent = formatTimerDigits(activeTimer.remainingSeconds);

  if (progressFillEl) {
    const total = activeTimer.totalSeconds || 1;
    const progress = Math.min(
      100,
      Math.max(0, ((total - activeTimer.remainingSeconds) / total) * 100),
    );
    progressFillEl.style.width = `${progress}%`;
  }

  if (statusEl) {
    let text = "Ready";
    let cls = "badge-ready";
    if (activeTimer.status === "running") {
      text = "Running";
      cls = "badge-studying";
    } else if (activeTimer.status === "paused") {
      text = "Paused";
      cls = "badge-paused";
    } else if (activeTimer.status === "completed") {
      text = "Finished";
      cls = "badge-completed";
    }
    statusEl.textContent = text;
    statusEl.className = `status-badge ${cls}`;
  }

  if (actionsEl) {
    if (activeTimer.status === "idle") {
      actionsEl.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-timer-start">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <span>Start</span>
        </button>
      `;
      document.getElementById("btn-timer-start")?.addEventListener("click", startTimer);
    } else if (activeTimer.status === "running") {
      actionsEl.innerHTML = `
        <button type="button" class="btn btn-secondary" id="btn-timer-pause">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/></svg>
          <span>Pause</span>
        </button>
        <button type="button" class="btn btn-danger" id="btn-timer-stop">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12"/></svg>
          <span>Stop</span>
        </button>
        <button type="button" class="btn btn-outline" id="btn-timer-reset">Reset</button>
      `;
      document.getElementById("btn-timer-pause")?.addEventListener("click", pauseTimer);
      document.getElementById("btn-timer-stop")?.addEventListener("click", stopTimer);
      document.getElementById("btn-timer-reset")?.addEventListener("click", resetTimer);
    } else if (activeTimer.status === "paused") {
      actionsEl.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-timer-resume">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          <span>Resume</span>
        </button>
        <button type="button" class="btn btn-danger" id="btn-timer-stop">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="6" width="12" height="12"/></svg>
          <span>Stop</span>
        </button>
        <button type="button" class="btn btn-outline" id="btn-timer-reset">Reset</button>
      `;
      document.getElementById("btn-timer-resume")?.addEventListener("click", resumeTimer);
      document.getElementById("btn-timer-stop")?.addEventListener("click", stopTimer);
      document.getElementById("btn-timer-reset")?.addEventListener("click", resetTimer);
    } else if (activeTimer.status === "completed") {
      actionsEl.innerHTML = `
        <button type="button" class="btn btn-primary" id="btn-timer-restart">
          <svg class="btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M23 4v6h-6"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/></svg>
          <span>Restart</span>
        </button>
        <button type="button" class="btn btn-outline" id="btn-timer-reset">Reset</button>
      `;
      document.getElementById("btn-timer-restart")?.addEventListener("click", () => {
        resetTimerState(activeTimer.totalSeconds);
        startTimer();
      });
      document.getElementById("btn-timer-reset")?.addEventListener("click", resetTimer);
    }
  }
}

function updateTimerDigits() {
  const digitsEl = document.getElementById("timer-digits-display");
  const progressFillEl = document.getElementById("timer-progress-fill");
  if (digitsEl && activeTimer) {
    digitsEl.textContent = formatTimerDigits(activeTimer.remainingSeconds);
  }
  if (progressFillEl && activeTimer) {
    const total = activeTimer.totalSeconds || 1;
    const progress = Math.min(
      100,
      Math.max(0, ((total - activeTimer.remainingSeconds) / total) * 100),
    );
    progressFillEl.style.width = `${progress}%`;
  }
}

function renderTimerPresets() {
  const container = document.getElementById("timer-presets-row");
  if (!container) return;

  container.innerHTML = TIMER_PRESETS.map((p) => {
    const totalSec = p.minutes * 60;
    const isSelected = activeTimer && activeTimer.totalSeconds === totalSec;
    return `
      <button 
        type="button" 
        class="timer-preset-chip ${isSelected ? "active" : ""}" 
        data-seconds="${totalSec}"
      >
        ${p.label}
      </button>
    `;
  }).join("");

  container.querySelectorAll(".timer-preset-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      const sec = parseInt(chip.getAttribute("data-seconds"), 10);
      if (sec) {
        setTimerDuration(sec);
        renderTimerPresets();
      }
    });
  });
}
