// Internal web floating timer removed. The Android app uses one native system-wide overlay.
export function initFloatingTimer() {}
export function showFloatingTimer() {}
export function hideFloatingTimer() {}
export function tickFloatingTimer() {}
