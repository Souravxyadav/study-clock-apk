/**
 * app.js
 * Main Application Orchestrator for Study Clock.
 * Single Page Application router for 5 sections: Clock, Study, Timer, History, Settings.
 */

import { initClock, stopClock } from "./clock.js";
import { initStudy } from "./study.js";
import { initTimer } from "./timer.js";
import { initHistory } from "./history.js";
import { initSettings, applyAppearanceSettings } from "./settings.js";
import { applyNativeOverlayCommand } from "./study.js";

const VALID_VIEWS = ["clock", "study", "timer", "history", "settings"];

export function switchView(viewName) {
  const targetView = VALID_VIEWS.includes(viewName) ? viewName : "clock";

  // Hide all sections, show target
  VALID_VIEWS.forEach((v) => {
    const el = document.getElementById(`view-${v}`);
    if (el) {
      el.style.display = v === targetView ? "block" : "none";
    }
  });

  // Update navigation items active state
  document.querySelectorAll("[data-nav-view]").forEach((navEl) => {
    const v = navEl.getAttribute("data-nav-view");
    if (v === targetView) {
      navEl.classList.add("active");
      navEl.setAttribute("aria-current", "page");
    } else {
      navEl.classList.remove("active");
      navEl.removeAttribute("aria-current");
    }
  });

  // Update URL hash without scroll jumps
  if (window.location.hash.slice(1) !== targetView) {
    history.replaceState(null, "", `#${targetView}`);
  }

  // Scroll to top
  window.scrollTo({ top: 0, behavior: "smooth" });

  // Initialize or resume view specific logic
  if (targetView === "clock") {
    initClock();
  } else {
    // If not on clock, pause clock ticks
    stopClock();
  }

  if (targetView === "study") {
    initStudy();
  } else if (targetView === "timer") {
    initTimer();
  } else if (targetView === "history") {
    initHistory();
  } else if (targetView === "settings") {
    initSettings();
  }

}

// Global bootstrap
document.addEventListener("DOMContentLoaded", () => {
  applyAppearanceSettings();
  window.__applyNativeOverlayCommand = (command) => {
    try { applyNativeOverlayCommand(command); } catch (e) { console.error(e); }
  };
  window.__overlayPermissionReady = () => {
    // Permission is ready; the native service will stay synchronized through the study state.
  };

  // External overlay commands always use the SAME Study page functions.
  // This keeps Pause / Resume / Finish behavior identical to the website.
  let nativePollBusy = false;
  const pollNativeCommand = () => {
    if (nativePollBusy || !window.AndroidStudyOverlay?.consumeOverlayCommand) return;
    nativePollBusy = true;
    try {
      const command = window.AndroidStudyOverlay.consumeOverlayCommand();
      if (command) applyNativeOverlayCommand(command);
    } catch (e) {
      console.error(e);
    } finally {
      nativePollBusy = false;
    }
  };
  setInterval(pollNativeCommand, 300);
  pollNativeCommand();

  // Attach navigation listeners
  document.querySelectorAll("[data-nav-view]").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.preventDefault();
      const view = btn.getAttribute("data-nav-view");
      if (view) switchView(view);
    });
  });

  // Initial route from hash or default to clock
  const initialHash = window.location.hash.replace("#", "").toLowerCase();
  const startView = VALID_VIEWS.includes(initialHash) ? initialHash : "clock";
  switchView(startView);

  // Handle browser back/forward buttons
  window.addEventListener("hashchange", () => {
    const hash = window.location.hash.replace("#", "").toLowerCase();
    if (VALID_VIEWS.includes(hash)) {
      switchView(hash);
    }
  });
});
