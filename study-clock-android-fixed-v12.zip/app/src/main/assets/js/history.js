/**
 * history.js
 * Dedicated Study & Timer History viewer,
 * analytics aggregator, task searching, individual deletion, and confirmation-protected clearing.
 */

import { getData, deleteHistoryItem, clearHistory } from "./storage.js";

let currentFilter = "all";
let currentSearch = "";
let historyListenersAttached = false;

export function initHistory() {
  renderHistoryView();
  attachHistoryListeners();
}

function attachHistoryListeners() {
  if (historyListenersAttached) return;
  historyListenersAttached = true;

  // Clear all history
  const clearBtn = document.getElementById("btn-clear-history");
  if (clearBtn) {
    clearBtn.addEventListener("click", () => {
      const data = getData();
      if (!data.history || data.history.length === 0) return;
      if (confirm("Are you sure you want to clear all session history records?")) {
        clearHistory();
        renderHistoryView();
      }
    });
  }

  // Filter chips (All | Study | Timer | Completed)
  const filterBtns = document.querySelectorAll(".history-filter-btn");
  filterBtns.forEach((btn) => {
    btn.addEventListener("click", () => {
      filterBtns.forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      currentFilter = btn.getAttribute("data-filter") || "all";
      renderHistoryView();
    });
  });

  // Search input
  const searchInput = document.getElementById("history-search-input");
  if (searchInput) {
    searchInput.addEventListener("input", (e) => {
      currentSearch = e.target.value.trim().toLowerCase();
      renderHistoryView();
    });
  }
}

export function renderHistoryView() {
  const container = document.getElementById("history-list-container");
  const countBadge = document.getElementById("history-count-badge");
  if (!container) return;

  const data = getData();
  const allHistory = data.history || [];

  // Update top analytics stat cards
  updateHistoryAnalytics(allHistory);

  // Apply filters
  let list = allHistory;
  if (currentFilter === "study") {
    list = list.filter((i) => i.type === "study");
  } else if (currentFilter === "timer") {
    list = list.filter((i) => i.type === "timer");
  } else if (currentFilter === "completed") {
    list = list.filter((i) => i.status === "completed");
  }

  // Apply search keyword
  if (currentSearch) {
    list = list.filter(
      (i) =>
        (i.template && i.template.toLowerCase().includes(currentSearch)) ||
        (i.task && i.task.toLowerCase().includes(currentSearch)),
    );
  }

  if (countBadge) {
    countBadge.textContent = `${list.length} records`;
  }

  if (list.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <svg class="empty-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
          <circle cx="12" cy="12" r="10"/>
          <polyline points="12 6 12 12 16 14"/>
        </svg>
        <p class="empty-title">No history records found</p>
        <p class="empty-desc">${currentSearch ? "Try adjusting your search terms or filters." : "Completed and tracked study or timer sessions will appear here automatically."}</p>
      </div>
    `;
    return;
  }

  container.innerHTML = list
    .map((item) => {
      const isCompleted = item.status === "completed";
      const durationFormatted = formatDuration(item.duration);
      const typeLabel = item.type === "study" ? "Study" : "Timer";
      const typeBadgeClass = item.type === "study" ? "type-study" : "type-timer";

      return `
      <div class="history-item-row" data-id="${item.id}">
        <div class="history-item-main">
          <div class="history-item-tags">
            <span class="history-tag ${typeBadgeClass}">${typeLabel}</span>
            <span class="history-tag ${isCompleted ? "status-done" : "status-unf"}">${item.status}</span>
          </div>
          <h4 class="history-item-title">${escapeHtml(item.template || "Session")}</h4>
          ${item.task ? `<div class="history-item-task"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width: 12px; height: 12px; margin-right: 4px; display: inline-block; vertical-align: middle;"><path d="M9 11l3 3L22 4"/><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11"/></svg>${escapeHtml(item.task)}</div>` : ""}
          <div class="history-item-meta">
            <span>${item.date}</span>
            <span>•</span>
            <span>${item.startTime || ""} – ${item.endTime || ""}</span>
          </div>
        </div>

        <div class="history-item-right">
          <span class="history-duration">${durationFormatted}</span>
          <button 
            type="button" 
            class="history-delete-btn" 
            title="Delete this record"
            data-delete-id="${item.id}"
            aria-label="Delete history item"
          >
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <polyline points="3 6 5 6 21 6"/>
              <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>
            </svg>
          </button>
        </div>
      </div>
    `;
    })
    .join("");

  // Attach individual delete listeners
  container.querySelectorAll(".history-delete-btn").forEach((btn) => {
    btn.addEventListener("click", (e) => {
      e.stopPropagation();
      const id = btn.getAttribute("data-delete-id");
      if (id) {
        deleteHistoryItem(id);
        renderHistoryView();
      }
    });
  });
}

function updateHistoryAnalytics(records) {
  const totalSeconds = records.reduce((acc, curr) => acc + (curr.duration || 0), 0);
  const totalH = Math.floor(totalSeconds / 3600);
  const totalM = Math.floor((totalSeconds % 3600) / 60);

  const totalTimeEl = document.getElementById("hist-total-time");
  if (totalTimeEl) {
    totalTimeEl.textContent = `${totalH}h ${totalM}m`;
  }

  const completionRateEl = document.getElementById("hist-completion-rate");
  if (completionRateEl) {
    if (records.length === 0) {
      completionRateEl.textContent = "0%";
    } else {
      const completedCount = records.filter((r) => r.status === "completed").length;
      const rate = Math.round((completedCount / records.length) * 100);
      completionRateEl.textContent = `${rate}%`;
    }
  }

  const studySessionsEl = document.getElementById("hist-study-sessions");
  if (studySessionsEl) {
    const studyCount = records.filter((r) => r.type === "study" && r.status === "completed").length;
    studySessionsEl.textContent = `${studyCount}`;
  }
}

function formatDuration(seconds = 0) {
  if (seconds < 60) {
    return `${Math.max(1, Math.round(seconds))}s`;
  }
  const m = Math.floor(seconds / 60);
  const h = Math.floor(m / 60);
  const remM = m % 60;
  if (h > 0) {
    return `${h}h ${remM > 0 ? `${remM}m` : ""}`;
  }
  return `${m}m`;
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
