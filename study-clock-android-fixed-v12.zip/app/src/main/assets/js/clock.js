/**
 * clock.js
 * Redesigned Clock Engine:
 * - 16+ visual templates (now managed in Settings exclusively, not on Clock page)
 * - Signature Black + Red Flip Clock & Analog/Digital dials
 * - Day & Solar Cycle Progress Tracker (elapsed, remaining, week & day of year)
 * - Live Multi-Timezone World Clocks (London, New York, Tokyo, Delhi, San Francisco, Sydney)
 * - OLED Nightstand / Dim Display Mode for bedtime desk viewing
 * - Hourly Web Audio Bell Chime toggle
 * - Study Goal & Focus snapshot with fast jump to Study mode
 * - Fullscreen Clock Mode
 */

import { getData, updateData } from "./storage.js";

export const CLOCK_TEMPLATES = [
  {
    id: "flip",
    name: "Flip Clock",
    category: "Flip",
    desc: "Realistic split-flap cards with red digits on black",
  },
  {
    id: "digital",
    name: "Clean Digital",
    category: "Digital",
    desc: "Balanced modern typography with smokey borders",
  },
  {
    id: "large-digital",
    name: "Large Digital",
    category: "Digital",
    desc: "Commanding headline size for across-the-room viewing",
  },
  {
    id: "minimal-digital",
    name: "Minimal Digital",
    category: "Digital",
    desc: "Featherweight elegance with quiet presence",
  },
  {
    id: "retro-digital",
    name: "Retro Digital",
    category: "Digital",
    desc: "Vintage 80s phosphor terminal styling",
  },
  {
    id: "seven-segment",
    name: "Seven Segment",
    category: "Digital",
    desc: "Sharp industrial 7-segment digital counter",
  },
  {
    id: "led-clock",
    name: "LED Clock",
    category: "Digital",
    desc: "Vibrant high-contrast dot LED display",
  },
  {
    id: "desk-clock",
    name: "Desk Clock",
    category: "Digital",
    desc: "Subtle beveled chassis resembling a physical nightstand clock",
  },
  {
    id: "typography-clock",
    name: "Typography Clock",
    category: "Digital",
    desc: "Serif-inspired editorial numerals and formatted date",
  },
  {
    id: "study-clock",
    name: "Study Clock",
    category: "Study",
    desc: "Tailored for long study blocks with calm proportions",
  },
  {
    id: "minimal-focus",
    name: "Minimal Focus Clock",
    category: "Study",
    desc: "Distraction-free quiet clock for intense sessions",
  },
  {
    id: "split-digital",
    name: "Split Digital",
    category: "Digital",
    desc: "Independent floating tiles for hours, minutes, seconds",
  },
  {
    id: "classic-analog",
    name: "Classic Analog",
    category: "Analog",
    desc: "Traditional circular dial with hour indices and smooth hands",
  },
  {
    id: "minimal-analog",
    name: "Minimal Analog",
    category: "Analog",
    desc: "Thin baton hands and subtle micro-dots",
  },
  {
    id: "modern-analog",
    name: "Modern Analog",
    category: "Analog",
    desc: "Monochrome architectural face with accent second hand",
  },
  {
    id: "roman-analog",
    name: "Roman Analog",
    category: "Analog",
    desc: "Refined Roman numerals dial face",
  },
];

const WORLD_CITIES = [
  { id: "london", city: "London, UK", tz: "Europe/London", code: "GMT/BST" },
  { id: "newyork", city: "New York, USA", tz: "America/New_York", code: "EDT" },
  { id: "tokyo", city: "Tokyo, Japan", tz: "Asia/Tokyo", code: "JST" },
  { id: "delhi", city: "New Delhi, India", tz: "Asia/Kolkata", code: "IST" },
  { id: "sf", city: "San Francisco, USA", tz: "America/Los_Angeles", code: "PDT" },
  { id: "sydney", city: "Sydney, Australia", tz: "Australia/Sydney", code: "AEST" },
];

let clockInterval = null;
let currentTemplate = "flip";
let currentFormat = "12h";
let currentShowSeconds = true;
let currentShowDate = true;
let currentNightMode = false;
let currentChimeEnabled = false;

// Audio context for chime
let chimeAudioCtx = null;
let lastChimeHour = -1;

// Keep previous digits to trigger flip animations
let prevFlipDigits = { h1: "", h2: "", m1: "", m2: "", s1: "", s2: "" };
let listenersAttached = false;
let isFullscreen = false;

export function initClock() {
  const data = getData();
  currentTemplate = data.settings.clock.template || "flip";
  currentFormat = data.settings.clock.format || "12h";
  currentShowSeconds = data.settings.clock.showSeconds ?? true;
  currentShowDate = data.settings.clock.showDate ?? true;
  currentNightMode = data.settings.clock.nightMode ?? false;
  currentChimeEnabled = data.settings.clock.chimeEnabled ?? false;

  applyNightMode(currentNightMode);
  updateClockControlsUI();
  attachClockToolbarListeners();

  if (clockInterval) clearInterval(clockInterval);
  tick();
  clockInterval = setInterval(tick, 250);
}

function attachClockToolbarListeners() {
  if (listenersAttached) return;
  listenersAttached = true;

  document.getElementById("clock-format-toggle")?.addEventListener("click", () => {
    toggleClockFormat();
  });

  document.getElementById("clock-seconds-toggle")?.addEventListener("click", () => {
    toggleClockSeconds();
  });

  document.getElementById("clock-date-toggle")?.addEventListener("click", () => {
    toggleClockDate();
  });

  document.getElementById("clock-night-toggle")?.addEventListener("click", () => {
    toggleNightMode();
  });

  document.getElementById("clock-chime-toggle")?.addEventListener("click", () => {
    toggleChime();
  });

  document.getElementById("clock-fullscreen-toggle")?.addEventListener("click", () => {
    enterClockFullscreen();
  });

  document.getElementById("btn-clock-launch-study")?.addEventListener("click", () => {
    // Jump to Study navigation item
    const studyNavBtn = document.querySelector('[data-nav-view="study"]');
    if (studyNavBtn) studyNavBtn.click();
  });

  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && isFullscreen) {
      exitClockFullscreen();
    }
  });

  // Handle native fullscreen change
  document.addEventListener("fullscreenchange", () => {
    if (!document.fullscreenElement && isFullscreen) {
      exitClockFullscreen(false);
    }
  });
}

export function enterClockFullscreen() {
  isFullscreen = true;
  document.body.classList.add("clock-fullscreen-active");

  let exitBtn = document.getElementById("clock-fullscreen-exit-btn");
  if (!exitBtn) {
    exitBtn = document.createElement("button");
    exitBtn.id = "clock-fullscreen-exit-btn";
    exitBtn.className = "clock-fullscreen-exit-btn";
    exitBtn.type = "button";
    exitBtn.setAttribute("aria-label", "Exit Fullscreen");
    exitBtn.innerHTML = `<span>✕ Exit Fullscreen (Esc)</span>`;
    exitBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      exitClockFullscreen();
    });
    document.body.appendChild(exitBtn);
  } else {
    exitBtn.style.display = "flex";
  }

  try {
    if (document.documentElement.requestFullscreen && !document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
    }
  } catch {
    // Ignore
  }

  tick();
}

export function exitClockFullscreen(exitNative = true) {
  isFullscreen = false;
  document.body.classList.remove("clock-fullscreen-active");

  const exitBtn = document.getElementById("clock-fullscreen-exit-btn");
  if (exitBtn) {
    exitBtn.style.display = "none";
  }

  if (exitNative && document.fullscreenElement) {
    try {
      document.exitFullscreen?.().catch(() => {});
    } catch {
      // Ignore
    }
  }

  tick();
}

export function stopClock() {
  if (clockInterval) {
    clearInterval(clockInterval);
    clockInterval = null;
  }
}

export function setClockTemplate(templateId) {
  currentTemplate = templateId;
  updateData({ settings: { clock: { template: templateId } } });
  tick();
}

export function toggleClockFormat() {
  currentFormat = currentFormat === "12h" ? "24h" : "12h";
  updateData({ settings: { clock: { format: currentFormat } } });
  updateClockControlsUI();
  tick();
}

export function toggleClockSeconds() {
  currentShowSeconds = !currentShowSeconds;
  updateData({ settings: { clock: { showSeconds: currentShowSeconds } } });
  updateClockControlsUI();
  tick();
}

export function toggleClockDate() {
  currentShowDate = !currentShowDate;
  updateData({ settings: { clock: { showDate: currentShowDate } } });
  updateClockControlsUI();
  tick();
}

export function toggleNightMode() {
  currentNightMode = !currentNightMode;
  updateData({ settings: { clock: { nightMode: currentNightMode } } });
  applyNightMode(currentNightMode);
  updateClockControlsUI();
}

function applyNightMode(active) {
  document.body.classList.toggle("clock-night-mode", active);
}

export function toggleChime() {
  currentChimeEnabled = !currentChimeEnabled;
  updateData({ settings: { clock: { chimeEnabled: currentChimeEnabled } } });
  updateClockControlsUI();
  if (currentChimeEnabled) {
    playChimeSound(); // brief test chime on activation
  }
}

function playChimeSound() {
  try {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!chimeAudioCtx) chimeAudioCtx = new AudioCtx();
    if (chimeAudioCtx.state === "suspended") chimeAudioCtx.resume();

    const now = chimeAudioCtx.currentTime;
    const osc1 = chimeAudioCtx.createOscillator();
    const osc2 = chimeAudioCtx.createOscillator();
    const gain = chimeAudioCtx.createGain();

    osc1.type = "sine";
    osc1.frequency.setValueAtTime(523.25, now); // C5
    osc2.type = "triangle";
    osc2.frequency.setValueAtTime(659.25, now); // E5

    gain.gain.setValueAtTime(0.001, now);
    gain.gain.exponentialRampToValueAtTime(0.2, now + 0.05);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 1.2);

    osc1.connect(gain);
    osc2.connect(gain);
    gain.connect(chimeAudioCtx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 1.2);
    osc2.stop(now + 1.2);
  } catch {
    // Ignore audio errors
  }
}

function updateClockControlsUI() {
  const formatBtn = document.getElementById("clock-format-toggle");
  if (formatBtn) formatBtn.textContent = currentFormat === "12h" ? "12H" : "24H";

  const secBtn = document.getElementById("clock-seconds-toggle");
  if (secBtn) {
    secBtn.setAttribute("data-active", currentShowSeconds ? "true" : "false");
    secBtn.textContent = currentShowSeconds ? "Seconds ON" : "Seconds OFF";
  }

  const dateBtn = document.getElementById("clock-date-toggle");
  if (dateBtn) {
    dateBtn.setAttribute("data-active", currentShowDate ? "true" : "false");
    dateBtn.textContent = currentShowDate ? "Date ON" : "Date OFF";
  }

  const nightBtn = document.getElementById("clock-night-toggle");
  if (nightBtn) {
    nightBtn.setAttribute("data-active", currentNightMode ? "true" : "false");
    nightBtn.classList.toggle("active", currentNightMode);
  }

  const chimeBtn = document.getElementById("clock-chime-toggle");
  const chimeLabel = document.getElementById("clock-chime-label");
  if (chimeBtn) {
    chimeBtn.setAttribute("data-active", currentChimeEnabled ? "true" : "false");
    chimeBtn.classList.toggle("active", currentChimeEnabled);
    if (chimeLabel) {
      chimeLabel.textContent = currentChimeEnabled ? "Chime ON" : "Chime OFF";
    }
  }

  // Also sync settings checkbox if present
  const settingChimeCb = document.getElementById("setting-clock-chime");
  if (settingChimeCb) settingChimeCb.checked = currentChimeEnabled;
  const settingNightCb = document.getElementById("setting-clock-night");
  if (settingNightCb) settingNightCb.checked = currentNightMode;
}

export function tick() {
  const container = document.getElementById("clock-stage");
  const now = new Date();

  // Hourly chime check
  if (currentChimeEnabled && now.getMinutes() === 0 && now.getSeconds() === 0) {
    if (lastChimeHour !== now.getHours()) {
      lastChimeHour = now.getHours();
      playChimeSound();
    }
  } else if (now.getMinutes() !== 0) {
    lastChimeHour = -1;
  }

  // Main stage rendering
  if (container) {
    let hours = now.getHours();
    const ampm = hours >= 12 ? "PM" : "AM";
    if (currentFormat === "12h") {
      hours = hours % 12 || 12;
    }
    const hoursStr = String(hours).padStart(2, "0");
    const minutesStr = String(now.getMinutes()).padStart(2, "0");
    const secondsStr = String(now.getSeconds()).padStart(2, "0");

    const dateOptions = { weekday: "short", month: "short", day: "numeric", year: "numeric" };
    const dateStr = now.toLocaleDateString(undefined, dateOptions);

    container.className = `clock-stage template-${currentTemplate}`;

    if (currentTemplate === "flip") {
      renderFlipClock(container, hoursStr, minutesStr, secondsStr, ampm, dateStr);
    } else if (currentTemplate.includes("analog")) {
      renderAnalogClock(container, now, dateStr);
    } else {
      renderDigitalClock(container, hoursStr, minutesStr, secondsStr, ampm, dateStr);
    }
  }

  // Update Day Cycle & Progress Tracker
  updateDayProgress(now);

  // Update World Clocks
  updateWorldClocks(now);

  // Update Focus Snapshot
  updateFocusSnapshot();
}

function updateDayProgress(now) {
  const totalSecondsInDay = 86400;
  const currentSeconds = now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds();
  const percent = Math.min(100, Math.max(0, (currentSeconds / totalSecondsInDay) * 100));

  const barFill = document.getElementById("clock-day-bar-fill");
  if (barFill) barFill.style.width = `${percent.toFixed(1)}%`;

  const percentPill = document.getElementById("clock-day-percent-pill");
  if (percentPill) percentPill.textContent = `${percent.toFixed(0)}% of Today`;

  const elapsedEl = document.getElementById("clock-day-elapsed");
  if (elapsedEl) elapsedEl.textContent = `${now.getHours()}h ${now.getMinutes()}m`;

  const remHours = 23 - now.getHours();
  const remMin = 59 - now.getMinutes();
  const remEl = document.getElementById("clock-day-remaining");
  if (remEl) remEl.textContent = `${remHours}h ${remMin}m`;

  // Calculate day of year & week of year
  const startOfYear = new Date(now.getFullYear(), 0, 1);
  const dayOfYear = Math.floor((now - startOfYear) / (24 * 60 * 60 * 1000)) + 1;
  const weekOfYear = Math.ceil(dayOfYear / 7);

  const metaEl = document.getElementById("clock-day-meta");
  if (metaEl) metaEl.textContent = `Day ${dayOfYear} • Wk ${weekOfYear}`;
}

function updateWorldClocks(now) {
  const grid = document.getElementById("clock-world-grid");
  if (!grid) return;

  const userHour = now.getHours();

  grid.innerHTML = WORLD_CITIES.map((c) => {
    try {
      const timeFmt = new Intl.DateTimeFormat("en-US", {
        timeZone: c.tz,
        hour: "numeric",
        minute: "2-digit",
        second: currentShowSeconds ? "2-digit" : undefined,
        hour12: currentFormat === "12h",
      });
      const timeStr = timeFmt.format(now);

      // Check hour in that timezone for day/night
      const hourFmt = new Intl.DateTimeFormat("en-US", {
        timeZone: c.tz,
        hour: "numeric",
        hour12: false,
      });
      const cityHour = parseInt(hourFmt.format(now), 10);
      const isDay = cityHour >= 6 && cityHour < 18;
      const sunMoon = isDay ? "☀️ Day" : "🌙 Night";

      // Hour difference
      let diff = cityHour - userHour;
      if (diff > 12) diff -= 24;
      if (diff < -12) diff += 24;
      const offsetSign = diff >= 0 ? `+${diff}` : `${diff}`;
      const offsetStr = `${c.code} (${offsetSign}h)`;

      return `
        <div class="world-clock-card">
          <div class="world-clock-header">
            <span class="world-clock-city" title="${c.city}">${c.city.split(",")[0]}</span>
            <span class="world-clock-sun-moon">${sunMoon}</span>
          </div>
          <div class="world-clock-time">${timeStr}</div>
          <div class="world-clock-offset">${offsetStr}</div>
        </div>
      `;
    } catch {
      return "";
    }
  }).join("");
}

function updateFocusSnapshot() {
  const metaText = document.getElementById("clock-focus-banner-text");
  if (!metaText) return;

  const data = getData();
  const goalMin = data.settings.study?.dailyGoalMinutes || 120;
  const todayStr = new Date().toISOString().split("T")[0];
  const todaySessions = (data.history || []).filter(
    (h) => h.type === "study" && h.date === todayStr,
  );
  const totalSecondsToday = todaySessions.reduce((acc, curr) => acc + (curr.duration || 0), 0);
  const todayMinutes = Math.round(totalSecondsToday / 60);

  metaText.textContent = `Daily Goal: ${goalMin}m • ${todayMinutes}m completed today`;
}

function renderFlipClock(container, hStr, mStr, sStr, ampm, dateStr) {
  const h1 = hStr[0];
  const h2 = hStr[1];
  const m1 = mStr[0];
  const m2 = mStr[1];
  const s1 = sStr[0];
  const s2 = sStr[1];

  const html = `
    <div class="flip-clock-wrapper">
      <div class="flip-clock-board">
        <div class="flip-digit-group">
          ${renderFlipCard(h1, prevFlipDigits.h1)}
          ${renderFlipCard(h2, prevFlipDigits.h2)}
        </div>
        <div class="flip-separator">:</div>
        <div class="flip-digit-group">
          ${renderFlipCard(m1, prevFlipDigits.m1)}
          ${renderFlipCard(m2, prevFlipDigits.m2)}
        </div>
        ${
          currentShowSeconds
            ? `
          <div class="flip-separator">:</div>
          <div class="flip-digit-group seconds">
            ${renderFlipCard(s1, prevFlipDigits.s1)}
            ${renderFlipCard(s2, prevFlipDigits.s2)}
          </div>
        `
            : ""
        }
        ${currentFormat === "12h" ? `<div class="flip-ampm-badge">${ampm}</div>` : ""}
      </div>
      ${currentShowDate ? `<div class="clock-date-line flip-date">${dateStr}</div>` : ""}
    </div>
  `;

  container.innerHTML = html;
  prevFlipDigits = { h1, h2, m1, m2, s1, s2 };
}

function renderFlipCard(digit, prevDigit) {
  const flipped = prevDigit !== "" && prevDigit !== digit ? "flipping" : "";
  return `
    <div class="flip-card ${flipped}">
      <div class="flip-card-inner">
        <span class="flip-digit">${digit}</span>
        <div class="flip-divider-line"></div>
      </div>
    </div>
  `;
}

function renderAnalogClock(container, now, dateStr) {
  const hours = now.getHours() % 12;
  const minutes = now.getMinutes();
  const seconds = now.getSeconds();
  const ms = now.getMilliseconds();

  const secDeg = (seconds + ms / 1000) * 6;
  const minDeg = (minutes + seconds / 60) * 6;
  const hourDeg = (hours + minutes / 60) * 30;

  const isRoman = currentTemplate === "roman-analog";
  const numerals = isRoman
    ? ["XII", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X", "XI"]
    : ["12", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11"];

  const markersHtml = numerals
    .map((n, i) => {
      const angle = i * 30;
      return `
      <div class="analog-numeral" style="--angle: ${angle}deg">
        <span>${n}</span>
      </div>
    `;
    })
    .join("");

  container.innerHTML = `
    <div class="analog-clock-wrapper">
      <div class="analog-dial">
        <div class="analog-markers">${markersHtml}</div>
        <div class="analog-hand hour-hand" style="transform: rotate(${hourDeg}deg)"></div>
        <div class="analog-hand min-hand" style="transform: rotate(${minDeg}deg)"></div>
        ${currentShowSeconds ? `<div class="analog-hand sec-hand" style="transform: rotate(${secDeg}deg)"></div>` : ""}
        <div class="analog-center-dot"></div>
      </div>
      ${currentShowDate ? `<div class="clock-date-line">${dateStr}</div>` : ""}
    </div>
  `;
}

function renderDigitalClock(container, hStr, mStr, sStr, ampm, dateStr) {
  container.innerHTML = `
    <div class="digital-clock-wrapper">
      <div class="digital-time-display">
        <span class="time-part hours">${hStr}</span>
        <span class="time-colon">:</span>
        <span class="time-part minutes">${mStr}</span>
        ${
          currentShowSeconds
            ? `
          <span class="time-colon">:</span>
          <span class="time-part seconds">${sStr}</span>
        `
            : ""
        }
        ${currentFormat === "12h" ? `<span class="time-ampm">${ampm}</span>` : ""}
      </div>
      ${currentShowDate ? `<div class="clock-date-line">${dateStr}</div>` : ""}
    </div>
  `;
}
