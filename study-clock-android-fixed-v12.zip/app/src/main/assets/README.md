# Study Clock

A clean, minimalist Study Clock and Timer web application built with HTML, CSS, Vanilla JavaScript, and LocalStorage.

## Features
- **Clock**: 15+ clock styles including Flip Clock (Black + Red), Minimal, Bauhaus, Terminal, Cyberpunk, and Fullscreen mode.
- **Study**: Structured study sessions, customizable durations, break intervals, session counters, and session history.
- **Timer**: Timestamp-accurate countdown timer with presets and custom duration.
- **History**: Filterable log of study and timer sessions with single-item delete and clear-all capabilities.
- **Settings**: Persistent configuration for clock template, time format (12/24H), seconds display, date display, and session defaults.

## Development
```sh
npm install
npm run dev
```

