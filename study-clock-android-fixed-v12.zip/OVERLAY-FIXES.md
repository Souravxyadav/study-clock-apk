# Study Clock Overlay Fixes

- Floating overlay is compact and draggable by the header.
- Double-tap the header opens Study Clock.
- Pause/Resume works directly from the overlay.
- Stop works directly from the overlay.
- Native overlay controls and the web Study timer share state through SharedPreferences + JS bridge.
- Overlay commands are queued until the WebView is available, so controls still work while another app is on screen.
- Countdown and count-up modes use timestamp-based timing.
- Close hides only the overlay; it does not end the study session.
- Existing HTML/CSS/JS Study Clock UI is preserved.
