# Study Clock v6 Overlay

- Keeps the website's existing Study Focus timer as the source of truth.
- Android external overlay remains enabled with Display over other apps permission.
- External Pause/Resume/Finish buttons invoke the same `applyNativeOverlayCommand()` path used by the website timer.
- When the app process/WebView is alive, commands are applied immediately to the website timer even while the activity is backgrounded.
- A SharedPreferences command is kept as a fallback so the website consumes it when it returns.
- External overlay is draggable; double-tap header opens Study Clock.
- Finish replaces Stop in the external overlay to match the website terminology.
