# Study Clock v8 Overlay

- Removed the in-app HTML floating timer completely.
- Kept one native Android system-wide floating window.
- External Pause/Resume/Finish queue commands that call the exact existing Study-page actions.
- Added compact minimize pill; the same single overlay window is used.
- Added 15 native visual templates; tap T1..T15 in the header to cycle.
- Added Study Clock app logo to overlay and Android app/notification icon.
- Overlay requires Display over other apps permission.
