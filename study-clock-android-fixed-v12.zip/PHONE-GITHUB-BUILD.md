# Study Clock APK — Phone-only build

This project wraps the existing website in an Android WebView and adds a native system-wide floating timer overlay.

## Build without a laptop

1. Create a GitHub account if needed.
2. Create a NEW PUBLIC repository, for example `study-clock-apk`.
3. Upload `study-clock-android-project.zip` to the repository.
4. Create this file in the repository:
   `.github/workflows/build-apk.yml`
5. Paste the workflow supplied with this package.
6. Open the **Actions** tab.
7. Open **Build Study Clock APK**.
8. Tap **Run workflow**.
9. Wait for the green check.
10. Open the workflow run and scroll to **Artifacts**.
11. Download `study-clock-debug-apk` on your Android phone.
12. Extract the ZIP and install the APK.
13. Open Study Clock.
14. Allow **Display over other apps**.
15. Allow notifications if Android asks.
16. The floating timer can now stay above other apps.

## Important

- The floating timer is a native Android overlay, not a browser popup.
- Android requires the user to explicitly allow overlay permission.
- The APK uses a foreground service so the timer can continue while other apps are open.
- Android 14+ requires a declared foreground-service type; this project uses `specialUse` for the user-controlled floating timer.
- OEM battery management may still stop background apps; if that happens, allow Study Clock to run without battery restrictions.
