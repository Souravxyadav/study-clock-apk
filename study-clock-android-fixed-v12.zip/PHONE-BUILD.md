# Study Clock APK - Phone Only Build

1. Create a GitHub repository named `study-clock-apk`.
2. Upload every file/folder from this project so `settings.gradle` is at repository root.
3. Create `.github/workflows/build-apk.yml` using the workflow supplied separately.
4. Commit changes.
5. GitHub -> Actions -> Build Study Clock APK -> Run workflow.
6. Wait for the green check.
7. Open the completed run -> Artifacts -> download `study-clock-debug-apk`.
8. Install the APK on Android.
9. Open Study Clock and allow **Display over other apps**.
10. Start a Study Focus session. The same timer will appear above other apps.
11. Pause/Resume/End from the floating overlay. Close removes the system overlay.

The Android overlay is synchronized from the website study session. It uses timestamps rather than a background-only counter, so it remains accurate when the app is backgrounded.
