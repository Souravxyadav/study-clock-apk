# Study Clock v9

- Native system-wide overlay remains the only floating timer.
- Internal web floating timer remains disabled.
- 8 structural floating templates are available from Settings.
- Template choice is persisted and immediately applied to the native overlay.
- Removed the in-app notification permission request. The app still creates the required foreground-service notification, but Android 13+ can keep it out of the notification drawer when notification permission is not granted.
- Added a Settings shortcut to Android app notification settings.
- Foreground-service Active Apps/Task Manager visibility cannot be programmatically hidden by a supported Android API.
