package com.sourav.studyclock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

public class FloatingTimerService extends Service {
    public static final String ACTION_SHOW = "SHOW";
    public static final String ACTION_CLOSE = "CLOSE";
    public static final String ACTION_START = "START";
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_RESUME = "RESUME";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_SYNC = "SYNC";

    private static final String PREF = "floating_timer";
    private static final String CHANNEL = "study_clock_overlay";
    private static final String COMMAND_KEY = "overlay_command";
    private static final long DEFAULT_SECONDS = 25 * 60L;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LinearLayout card;
    private TextView timerText;
    private TextView statusText;
    private TextView titleText;
    private Button actionButton;
    private Button stopButton;
    private Handler handler;
    private boolean attached;
    private boolean running;
    private boolean paused;
    private boolean countdownMode = true;
    private long remaining = DEFAULT_SECONDS;
    private long endAt;
    private long countUpStartedAt;
    private String label = "Study Focus";
    private static FloatingTimerService instance;

    private float downX, downY;
    private int startX, startY;
    private long lastTapAt;
    private boolean moved;

    public static boolean isRunning() { return instance != null; }

    public static void updateFromWeb(long seconds, boolean webRunning, boolean webPaused,
                                     String webLabel, boolean countdown) {
        FloatingTimerService service = instance;
        if (service == null) return;
        service.handler.post(() -> service.applyWebState(seconds, webRunning, webPaused,
                webLabel, countdown));
    }

    public static String consumeOverlayCommand(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        String command = p.getString(COMMAND_KEY, "");
        if (command == null || command.isEmpty()) return "";
        p.edit().remove(COMMAND_KEY).apply();
        return command;
    }

    public static String getOverlayState(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        JSONObject o = new JSONObject();
        try {
            o.put("seconds", p.getLong("remaining", DEFAULT_SECONDS));
            o.put("running", p.getBoolean("running", false));
            o.put("paused", p.getBoolean("paused", false));
            o.put("countdown", p.getBoolean("countdownMode", true));
            o.put("label", p.getString("label", "Study Focus"));
        } catch (Exception ignored) {}
        return o.toString();
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        handler = new Handler(getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForegroundCompat();
        loadState();
        if (Settings.canDrawOverlays(this)) createOverlay();
        tick();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (action == null) action = ACTION_SHOW;

        switch (action) {
            case ACTION_START: startTimer(); break;
            case ACTION_PAUSE: pauseTimer(true); break;
            case ACTION_RESUME: resumeTimer(true); break;
            case ACTION_STOP: stopTimer(true); break;
            case ACTION_SYNC: syncFromWeb(intent); break;
            case ACTION_CLOSE: closeOverlay(); break;
            default:
                if (Settings.canDrawOverlays(this) && card == null) createOverlay();
                else showOverlay();
                break;
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("Study Clock")
                .setContentText("Study Focus timer is active")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1001, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(
                    CHANNEL, "Study Clock Floating Timer", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Floating Study Focus timer");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private GradientDrawable bg(int color, float radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView makeText(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button makeButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(35, 35, 40));
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        b.setBackground(bg(Color.WHITE, 12, Color.rgb(220, 220, 225)));
        return b;
    }

    private void createOverlay() {
        if (!Settings.canDrawOverlays(this)) return;

        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(9), dp(12), dp(10));
        card.setBackground(bg(Color.argb(246, 250, 250, 252), 18, Color.argb(80, 80, 80, 80)));
        card.setElevation(dp(10));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(0, 0, 0, dp(3));

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        titleWrap.setPadding(0, 0, dp(8), 0);

        titleText = makeText("Study Focus", 15, Color.rgb(55, 55, 60));
        titleText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusText = makeText("Studying", 10, Color.rgb(105, 105, 110));
        titleWrap.addView(titleText);
        titleWrap.addView(statusText);
        header.addView(titleWrap, new LinearLayout.LayoutParams(0, dp(42), 1));

        Button close = makeButton("×");
        close.setTextSize(20);
        close.setTextColor(Color.rgb(90, 90, 95));
        close.setBackgroundColor(Color.TRANSPARENT);
        close.setOnClickListener(v -> closeOverlay());
        header.addView(close, new LinearLayout.LayoutParams(dp(38), dp(42)));
        card.addView(header);

        timerText = makeText(format(remaining), 27, Color.rgb(25, 25, 30));
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        timerText.setGravity(Gravity.CENTER);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, dp(54)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        controls.setPadding(0, dp(4), 0, 0);

        actionButton = makeButton("Pause");
        actionButton.setOnClickListener(v -> {
            if (running) pauseTimer(true); else if (paused) resumeTimer(true);
        });

        stopButton = makeButton("Finish");
        stopButton.setTextColor(Color.rgb(190, 55, 55));
        stopButton.setOnClickListener(v -> stopTimer(true));

        controls.addView(actionButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        controls.addView(stopButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        card.addView(controls);

        attachDragAndDoubleTap(header);

        params = new WindowManager.LayoutParams(
                dp(320),
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(16);
        params.y = dp(110);
        showOverlay();
    }

    private void attachDragAndDoubleTap(View handle) {
        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    startX = params.x;
                    startY = params.y;
                    moved = false;
                    return true;

                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downX;
                    float dy = event.getRawY() - downY;
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                    if (attached && moved) {
                        params.x = startX + (int) dx;
                        params.y = startY + (int) dy;
                        clampPosition();
                        wm.updateViewLayout(card, params);
                    }
                    return true;

                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        long now = System.currentTimeMillis();
                        if (now - lastTapAt < 320) {
                            openApp();
                            lastTapAt = 0;
                        } else {
                            lastTapAt = now;
                        }
                    }
                    return true;
            }
            return true;
        });
    }

    private void clampPosition() {
        if (wm == null || card == null) return;
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int maxX = Math.max(dp(8), width - dp(320) - dp(8));
        int maxY = Math.max(dp(8), height - card.getMeasuredHeight() - dp(8));
        params.x = Math.max(dp(8), Math.min(params.x, maxX));
        params.y = Math.max(dp(8), Math.min(params.y, maxY));
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private void showOverlay() {
        if (card == null || !Settings.canDrawOverlays(this)) return;
        if (!attached) {
            try {
                wm.addView(card, params);
                attached = true;
            } catch (Exception ignored) {}
        }
        if (card != null) card.setVisibility(View.VISIBLE);
        updateControls();
    }

    private void closeOverlay() {
        if (attached && card != null) {
            try { wm.removeView(card); } catch (Exception ignored) {}
            attached = false;
        }
        saveState();
    }

    private void syncFromWeb(Intent intent) {
        if (intent == null) return;
        applyWebState(
                Math.max(0L, intent.getLongExtra("remainingSeconds", remaining)),
                intent.getBooleanExtra("running", false),
                intent.getBooleanExtra("paused", false),
                intent.getStringExtra("label"),
                intent.getBooleanExtra("countdown", true)
        );
    }

    private void applyWebState(long seconds, boolean webRunning, boolean webPaused,
                               String webLabel, boolean countdown) {
        String pending = getSharedPreferences(PREF, MODE_PRIVATE).getString(COMMAND_KEY, "");
        if (pending != null && !pending.isEmpty()) return;

        countdownMode = countdown;
        remaining = Math.max(0L, seconds);
        running = webRunning;
        paused = webPaused;
        label = (webLabel == null || webLabel.trim().isEmpty()) ? "Study Focus" : webLabel;

        long now = System.currentTimeMillis();
        if (countdownMode) {
            endAt = running ? now + remaining * 1000L : 0L;
            countUpStartedAt = 0L;
        } else {
            countUpStartedAt = running ? now - remaining * 1000L : 0L;
            endAt = 0L;
        }

        saveState();
        if (running || paused) showOverlay();
        updateControls();
    }

    private void startTimer() {
        if (Settings.canDrawOverlays(this) && card == null) createOverlay();
        if (remaining <= 0) remaining = DEFAULT_SECONDS;
        paused = false;
        running = true;
        if (countdownMode) endAt = System.currentTimeMillis() + remaining * 1000L;
        else countUpStartedAt = System.currentTimeMillis() - remaining * 1000L;
        queueCommand("start");
        saveState();
        updateControls();
    }

    private void pauseTimer(boolean fromOverlay) {
        if (!running) return;
        long now = System.currentTimeMillis();
        if (countdownMode) remaining = Math.max(0L, (endAt - now + 999) / 1000L);
        else if (countUpStartedAt > 0) remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
        running = false;
        paused = true;
        endAt = 0L;
        if (fromOverlay) queueCommand("pause");
        saveState();
        updateControls();
        if (Settings.canDrawOverlays(this)) showOverlay();
    }

    private void resumeTimer(boolean fromOverlay) {
        if (!paused) return;
        long now = System.currentTimeMillis();
        if (countdownMode) endAt = now + remaining * 1000L;
        else countUpStartedAt = now - remaining * 1000L;
        running = true;
        paused = false;
        if (fromOverlay) queueCommand("resume");
        saveState();
        updateControls();
        if (Settings.canDrawOverlays(this)) showOverlay();
    }

    private void stopTimer(boolean fromOverlay) {
        running = false;
        paused = false;
        endAt = 0L;
        countUpStartedAt = 0L;
        remaining = 0L;
        if (fromOverlay) queueCommand("stop");
        saveState();
        updateControls();
        closeOverlay();
        stopSelf();
    }

    private void queueCommand(String command) {
        // Keep a fallback command for the next WebView sync/resume.
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putString(COMMAND_KEY, command)
                .apply();
        // If the main Study Clock WebView still exists, invoke the SAME JS study
        // command immediately. This keeps the website timer authoritative.
        MainActivity.applyOverlayCommandFromService(command, getOverlayState(this));
    }

    private void updateControls() {
        if (titleText != null) titleText.setText(label);
        if (statusText != null) {
            statusText.setText(running ? "Studying" : paused ? "Paused" : "Study Focus");
        }
        if (actionButton != null) {
            actionButton.setText(running ? "Pause" : paused ? "Resume" : "Pause");
            actionButton.setEnabled(running || paused);
        }
        if (stopButton != null) stopButton.setEnabled(running || paused);
        if (timerText != null) timerText.setText(format(remaining));
    }

    private void tick() {
        if (running) {
            long now = System.currentTimeMillis();
            if (countdownMode) {
                remaining = Math.max(0L, (endAt - now + 999L) / 1000L);
                if (remaining == 0L) {
                    running = false;
                    paused = false;
                    queueCommand("complete");
                    saveState();
                    closeOverlay();
                }
            } else if (countUpStartedAt > 0) {
                remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
            }
            if (timerText != null) timerText.setText(format(remaining));
            saveState();
        }
        handler.postDelayed(this::tick, 500);
    }

    private String format(long seconds) {
        long h = seconds / 3600;
        long m = (seconds % 3600) / 60;
        long s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }

    private void loadState() {
        android.content.SharedPreferences p = getSharedPreferences(PREF, MODE_PRIVATE);
        remaining = p.getLong("remaining", DEFAULT_SECONDS);
        endAt = p.getLong("endAt", 0L);
        running = p.getBoolean("running", false);
        paused = p.getBoolean("paused", false);
        countdownMode = p.getBoolean("countdownMode", true);
        countUpStartedAt = p.getLong("countUpStartedAt", 0L);
        label = p.getString("label", "Study Focus");

        if (running) {
            if (countdownMode && endAt > 0) {
                remaining = Math.max(0L, (endAt - System.currentTimeMillis() + 999L) / 1000L);
                if (remaining == 0L) running = false;
            } else if (!countdownMode && countUpStartedAt > 0) {
                remaining = Math.max(0L, (System.currentTimeMillis() - countUpStartedAt) / 1000L);
            }
        }
    }

    private void saveState() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putLong("remaining", remaining)
                .putLong("endAt", endAt)
                .putBoolean("running", running)
                .putBoolean("paused", paused)
                .putBoolean("countdownMode", countdownMode)
                .putLong("countUpStartedAt", countUpStartedAt)
                .putString("label", label)
                .apply();
    }

    @Override public void onDestroy() {
        if (attached && card != null) {
            try { wm.removeView(card); } catch (Exception ignored) {}
        }
        attached = false;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
