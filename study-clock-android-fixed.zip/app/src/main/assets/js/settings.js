/**
 * settings.js
 * Settings manager for Clock, Study, Timer, Appearance, and Data Export/Import/Reset.
 * Displays all 18 visual Study Templates cards with active selection here in Settings.
 */

import { getData, updateData, resetData, exportData, importData, clearHistory } from "./storage.js";
import { CLOCK_TEMPLATES, setClockTemplate } from "./clock.js";
import { STUDY_TEMPLATES, selectStudyTemplate, setDailyStudyGoal } from "./study.js";

export function initSettings() {
  populateSettingsForm();
  renderSettingsClockTemplates();
  renderSettingsStudyTemplates();
  attachSettingsListeners();
}

export function populateSettingsForm() {
  const data = getData();

  // Clock
  const clockTemplateSelect = document.getElementById("setting-clock-template");
  if (clockTemplateSelect) {
    clockTemplateSelect.innerHTML = CLOCK_TEMPLATES.map(
      (t) => `<option value="${t.id}">${t.name} (${t.category})</option>`,
    ).join("");
    clockTemplateSelect.value = data.settings.clock.template || "flip";
  }

  const clockFormatSelect = document.getElementById("setting-clock-format");
  if (clockFormatSelect) clockFormatSelect.value = data.settings.clock.format || "12h";

  const showSecondsCheckbox = document.getElementById("setting-clock-seconds");
  if (showSecondsCheckbox) showSecondsCheckbox.checked = data.settings.clock.showSeconds ?? true;

  const showDateCheckbox = document.getElementById("setting-clock-date");
  if (showDateCheckbox) showDateCheckbox.checked = data.settings.clock.showDate ?? true;

  const chimeCheckbox = document.getElementById("setting-clock-chime");
  if (chimeCheckbox) chimeCheckbox.checked = data.settings.clock.chimeEnabled ?? false;

  const nightCheckbox = document.getElementById("setting-clock-night");
  if (nightCheckbox) nightCheckbox.checked = data.settings.clock.nightMode ?? false;

  // Study
  const dailyGoalInput = document.getElementById("setting-study-daily-goal");
  if (dailyGoalInput) dailyGoalInput.value = data.settings.study.dailyGoalMinutes || 120;

  const studyTemplateSelect = document.getElementById("setting-study-template");
  if (studyTemplateSelect) {
    studyTemplateSelect.innerHTML = STUDY_TEMPLATES.map(
      (t) => `<option value="${t.id}">${t.name} (${t.studyMin}m / ${t.breakMin}m)</option>`,
    ).join("");
    studyTemplateSelect.value = data.settings.study.defaultTemplate || "classic";
  }

  const defaultStudyMinutesInput = document.getElementById("setting-study-duration");
  if (defaultStudyMinutesInput)
    defaultStudyMinutesInput.value = data.settings.study.defaultStudyMinutes || 25;

  const defaultBreakMinutesInput = document.getElementById("setting-study-break");
  if (defaultBreakMinutesInput)
    defaultBreakMinutesInput.value = data.settings.study.defaultBreakMinutes || 5;

  const autoBreakCheckbox = document.getElementById("setting-study-auto-break");
  if (autoBreakCheckbox) autoBreakCheckbox.checked = data.settings.study.autoStartBreak ?? false;

  const autoNextCheckbox = document.getElementById("setting-study-auto-next");
  if (autoNextCheckbox)
    autoNextCheckbox.checked = data.settings.study.autoStartNextSession ?? false;

  // Timer
  const timerDefaultInput = document.getElementById("setting-timer-duration");
  if (timerDefaultInput)
    timerDefaultInput.value = Math.round((data.settings.timer.defaultDurationSeconds || 1500) / 60);

  // Appearance
  const densitySelect = document.getElementById("setting-appearance-density");
  if (densitySelect) densitySelect.value = data.settings.appearance.density || "comfortable";

  const accentSelect = document.getElementById("setting-appearance-accent");
  if (accentSelect) accentSelect.value = data.settings.appearance.accent || "coral";
}

export function renderSettingsClockTemplates() {
  const container = document.getElementById("settings-clock-templates-grid");
  if (!container) return;

  const data = getData();
  const currentTemplateId = data.settings.clock?.template || "flip";

  container.innerHTML = CLOCK_TEMPLATES.map((t) => {
    const isSelected = t.id === currentTemplateId;
    return `
      <button 
        type="button" 
        class="clock-template-card ${isSelected ? "active" : ""}" 
        data-template="${t.id}"
      >
        <div class="template-header">
          <span class="template-name">${t.name}</span>
          <span class="template-tag">${t.category}</span>
        </div>
        <p class="template-desc">${t.desc}</p>
      </button>
    `;
  }).join("");

  container.querySelectorAll(".clock-template-card").forEach((btn) => {
    btn.addEventListener("click", () => {
      const tid = btn.getAttribute("data-template");
      if (tid) {
        setClockTemplate(tid);
        const selectEl = document.getElementById("setting-clock-template");
        if (selectEl) selectEl.value = tid;
        renderSettingsClockTemplates();
      }
    });
  });
}

export function renderSettingsStudyTemplates() {
  const container = document.getElementById("settings-study-templates-grid");
  if (!container) return;

  const data = getData();
  const currentTemplateId = data.settings.study?.defaultTemplate || "classic";

  container.innerHTML = STUDY_TEMPLATES.map((t) => {
    const isSelected = t.id === currentTemplateId;
    return `
      <button 
        type="button" 
        class="study-template-card ${isSelected ? "active" : ""}" 
        data-template="${t.id}"
      >
        <div class="template-header">
          <span class="template-name">${t.name}</span>
          <span class="template-duration">${t.studyMin}m</span>
        </div>
        <p class="template-desc">${t.desc}</p>
        <div class="template-meta">
          <span>Break: ${t.breakMin}m</span>
          <span>Target: ${t.targetSessions} runs</span>
        </div>
      </button>
    `;
  }).join("");

  container.querySelectorAll(".study-template-card").forEach((card) => {
    card.addEventListener("click", () => {
      const tid = card.getAttribute("data-template");
      if (tid) {
        updateData({ settings: { study: { defaultTemplate: tid } } });
        selectStudyTemplate(tid);
        const selectEl = document.getElementById("setting-study-template");
        if (selectEl) selectEl.value = tid;
        renderSettingsStudyTemplates();
      }
    });
  });
}

function attachSettingsListeners() {
  // Clock settings changes
  document.getElementById("setting-clock-template")?.addEventListener("change", (e) => {
    setClockTemplate(e.target.value);
    renderSettingsClockTemplates();
  });

  document.getElementById("setting-clock-format")?.addEventListener("change", (e) => {
    updateData({ settings: { clock: { format: e.target.value } } });
  });

  document.getElementById("setting-clock-seconds")?.addEventListener("change", (e) => {
    updateData({ settings: { clock: { showSeconds: e.target.checked } } });
  });

  document.getElementById("setting-clock-date")?.addEventListener("change", (e) => {
    updateData({ settings: { clock: { showDate: e.target.checked } } });
  });

  document.getElementById("setting-clock-chime")?.addEventListener("change", (e) => {
    updateData({ settings: { clock: { chimeEnabled: e.target.checked } } });
  });

  document.getElementById("setting-clock-night")?.addEventListener("change", (e) => {
    updateData({ settings: { clock: { nightMode: e.target.checked } } });
    document.body.classList.toggle("clock-night-mode", e.target.checked);
  });

  // Study settings changes
  document.getElementById("setting-study-daily-goal")?.addEventListener("change", (e) => {
    const val = Math.max(5, parseInt(e.target.value, 10) || 120);
    setDailyStudyGoal(val);
  });

  document.getElementById("setting-study-template")?.addEventListener("change", (e) => {
    const tid = e.target.value;
    updateData({ settings: { study: { defaultTemplate: tid } } });
    selectStudyTemplate(tid);
    renderSettingsStudyTemplates();
  });

  document.getElementById("setting-study-duration")?.addEventListener("change", (e) => {
    const val = Math.max(1, parseInt(e.target.value, 10) || 25);
    updateData({ settings: { study: { defaultStudyMinutes: val } } });
  });

  document.getElementById("setting-study-break")?.addEventListener("change", (e) => {
    const val = Math.max(0, parseInt(e.target.value, 10) || 5);
    updateData({ settings: { study: { defaultBreakMinutes: val } } });
  });

  document.getElementById("setting-study-auto-break")?.addEventListener("change", (e) => {
    updateData({ settings: { study: { autoStartBreak: e.target.checked } } });
  });

  document.getElementById("setting-study-auto-next")?.addEventListener("change", (e) => {
    updateData({ settings: { study: { autoStartNextSession: e.target.checked } } });
  });

  // Timer settings
  document.getElementById("setting-timer-duration")?.addEventListener("change", (e) => {
    const minutes = Math.max(1, parseInt(e.target.value, 10) || 25);
    updateData({ settings: { timer: { defaultDurationSeconds: minutes * 60 } } });
  });

  // Appearance
  document.getElementById("setting-appearance-density")?.addEventListener("change", (e) => {
    updateData({ settings: { appearance: { density: e.target.value } } });
    applyAppearanceSettings();
  });

  document.getElementById("setting-appearance-accent")?.addEventListener("change", (e) => {
    updateData({ settings: { appearance: { accent: e.target.value } } });
    applyAppearanceSettings();
  });

  function showStatus(text, isError = false) {
    const el = document.getElementById("settings-status-msg");
    if (!el) return;
    el.style.display = "block";
    el.style.background = isError ? "rgba(224, 49, 49, 0.1)" : "rgba(18, 184, 134, 0.1)";
    el.style.color = isError ? "var(--danger)" : "var(--success)";
    el.style.border = `1px solid ${isError ? "rgba(224, 49, 49, 0.3)" : "rgba(18, 184, 134, 0.3)"}`;
    el.textContent = text;
    setTimeout(() => {
      el.style.display = "none";
    }, 4000);
  }

  // Data Actions
  document.getElementById("btn-export-data")?.addEventListener("click", () => {
    exportData();
    showStatus("Data exported successfully!");
  });

  document.getElementById("file-import-input")?.addEventListener("change", (e) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result;
      const res = importData(content);
      if (res.success) {
        showStatus("Data imported successfully!");
        populateSettingsForm();
        renderSettingsStudyTemplates();
      } else {
        showStatus(`Failed to import data: ${res.error}`, true);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  });

  document.getElementById("btn-import-trigger")?.addEventListener("click", () => {
    document.getElementById("file-import-input")?.click();
  });

  document.getElementById("btn-reset-app")?.addEventListener("click", () => {
    if (confirm("Reset all settings to default values?")) {
      resetData();
      populateSettingsForm();
      renderSettingsStudyTemplates();
      showStatus("Settings reset to defaults.");
    }
  });

  document.getElementById("btn-clear-all-data")?.addEventListener("click", () => {
    if (confirm("Are you sure you want to clear all history?")) {
      clearHistory();
      showStatus("All study and timer history cleared.");
    }
  });

  applyAppearanceSettings();
}

export function applyAppearanceSettings() {
  const data = getData();
  const density = data.settings.appearance.density || "comfortable";
  const accent = data.settings.appearance.accent || "coral";

  document.documentElement.setAttribute("data-density", density);
  document.documentElement.setAttribute("data-accent", accent);
}
