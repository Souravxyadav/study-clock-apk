package com.sourav.studyclock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private static final int REQ_NOTIFICATIONS = 42;
    private boolean overlayRequested = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidStudyOverlay");
        webView.loadUrl("file:///android_asset/index.html");

        requestNotificationPermission();
        // Overlay permission is requested when the user starts the study timer.

    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATIONS);
        }
    }

    private void ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            startFloatingService();
            return;
        }
        if (!overlayRequested) {
            overlayRequested = true;
            Toast.makeText(this, "Allow 'Display over other apps' for the floating timer", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        }
    }

    private void startFloatingService() {
        if (!Settings.canDrawOverlays(this)) {
            ensureOverlayPermission();
            return;
        }
        Intent intent = new Intent(this, FloatingTimerService.class);
        intent.setAction(FloatingTimerService.ACTION_SHOW);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Do not create an overlay automatically on every app resume.
        // The web timer explicitly asks for it when a study session is active.
        if (Settings.canDrawOverlays(this) && webView != null && overlayRequested) {
            webView.evaluateJavascript("window.__overlayPermissionReady && window.__overlayPermissionReady()", null);
            overlayRequested = false;
        }
    }

    public class AndroidBridge {
        @JavascriptInterface public void showOverlay() { startFloatingService(); }
        @JavascriptInterface public void hideOverlay() { send(FloatingTimerService.ACTION_CLOSE); }
        @JavascriptInterface public void startTimer() { send(FloatingTimerService.ACTION_START); }
        @JavascriptInterface public void pauseTimer() { send(FloatingTimerService.ACTION_PAUSE); }
        @JavascriptInterface public void resumeTimer() { send(FloatingTimerService.ACTION_RESUME); }
        @JavascriptInterface public void stopTimer() { send(FloatingTimerService.ACTION_STOP); }
        @JavascriptInterface public void syncTimer(long remainingSeconds, boolean running, boolean paused, String label) {
            Intent i = new Intent(MainActivity.this, FloatingTimerService.class);
            i.setAction(FloatingTimerService.ACTION_SYNC);
            i.putExtra("remainingSeconds", Math.max(0L, remainingSeconds));
            i.putExtra("running", running);
            i.putExtra("paused", paused);
            i.putExtra("label", label == null ? "Study Focus" : label);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }

        @JavascriptInterface public boolean hasOverlayPermission() { return Settings.canDrawOverlays(MainActivity.this); }
        @JavascriptInterface public void requestOverlayPermission() { ensureOverlayPermission(); }

        private void send(String action) {
            Intent i = new Intent(MainActivity.this, FloatingTimerService.class);
            i.setAction(action);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
        }
    }
}
