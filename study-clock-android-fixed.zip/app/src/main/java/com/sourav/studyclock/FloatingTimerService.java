package com.sourav.studyclock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.Locale;

public class FloatingTimerService extends Service {
    public static final String ACTION_SHOW = "SHOW";
    public static final String ACTION_CLOSE = "CLOSE";
    public static final String ACTION_START = "START";
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_RESUME = "RESUME";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_SYNC = "SYNC";

    private static final String PREF = "floating_timer";
    private static final String CHANNEL = "study_clock_overlay";
    private static final long DEFAULT_SECONDS = 25 * 60L;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private LinearLayout card;
    private TextView timerText;
    private TextView statusText;
    private Button actionButton;
    private Handler handler;
    private boolean attached = false;
    private boolean minimized = false;
    private boolean running = false;
    private long remaining = DEFAULT_SECONDS;
    private long endAt = 0L;
    private float downX, downY;
    private int startX, startY;

    @Override public void onCreate() {
        super.onCreate();
        handler = new Handler(getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForegroundCompat();
        loadState();
        createOverlay();
        tick();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = intent == null ? ACTION_SHOW : intent.getAction();
        if (a == null) a = ACTION_SHOW;
        switch (a) {
            case ACTION_START: startTimer(); break;
            case ACTION_PAUSE: pauseTimer(); break;
            case ACTION_RESUME: resumeTimer(); break;
            case ACTION_STOP: stopTimer(); break;
            case ACTION_SYNC:
                syncFromWeb(intent);
                break;
            case ACTION_CLOSE: closeOverlay(); break;
            default: showOverlay(); break;
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("Study Clock")
                .setContentText("Floating study timer is active")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(1001, n);
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Study Clock Floating Timer", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the floating study timer running");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private GradientDrawable bg(int radius) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.argb(235, 248, 248, 248));
        g.setCornerRadius(radius);
        g.setStroke(1, Color.argb(80, 80, 80, 80));
        return g;
    }

    private void createOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 12, 18, 12);
        card.setBackground(bg(28));
        card.setElevation(18f);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("Study Clock", 14, Color.DKGRAY);
        header.addView(title, new LinearLayout.LayoutParams(0, 40, 1));
        Button close = button("×");
        close.setOnClickListener(v -> closeOverlay());
        header.addView(close, new LinearLayout.LayoutParams(42, 40));
        card.addView(header);

        statusText = text("Ready", 11, Color.GRAY);
        card.addView(statusText);
        timerText = text(format(remaining), 30, Color.rgb(35,35,35));
        timerText.setGravity(Gravity.CENTER);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, 58));

        LinearLayout controls = new LinearLayout(this);
        controls.setGravity(Gravity.CENTER);
        actionButton = button(running ? "Pause" : "Start");
        actionButton.setOnClickListener(v -> toggleTimer());
        Button stop = button("Stop");
        stop.setOnClickListener(v -> stopTimer());
        Button min = button("—");
        min.setOnClickListener(v -> toggleMinimize());
        controls.addView(actionButton, new LinearLayout.LayoutParams(0, 44, 1));
        controls.addView(stop, new LinearLayout.LayoutParams(0, 44, 1));
        controls.addView(min, new LinearLayout.LayoutParams(50, 44));
        card.addView(controls);

        View drag = header;
        drag.setOnTouchListener((v, e) -> {
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX = e.getRawX(); downY = e.getRawY(); startX = params.x; startY = params.y; return true;
            }
            if (e.getAction() == MotionEvent.ACTION_MOVE) {
                params.x = startX + (int)(e.getRawX() - downX);
                params.y = startY + (int)(e.getRawY() - downY);
                if (attached) wm.updateViewLayout(card, params);
                return true;
            }
            return e.getAction() == MotionEvent.ACTION_UP;
        });

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 18; params.y = 90;
        showOverlay();
    }

    private TextView text(String s, int size, int color) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextSize(12); b.setAllCaps(false); b.setTextColor(Color.DKGRAY); b.setBackground(bg(18)); return b;
    }

    private void showOverlay() {
        if (card == null || !Settings.canDrawOverlays(this)) return;
        if (!attached) { wm.addView(card, params); attached = true; }
        card.setVisibility(View.VISIBLE);
        updateMinimized();
    }

    private void closeOverlay() {
        saveState();
        if (attached) { try { wm.removeView(card); } catch (Exception ignored) {} attached = false; }
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void toggleMinimize() { minimized = !minimized; updateMinimized(); saveState(); }
    private void updateMinimized() {
        if (card == null) return;
        int childCount = card.getChildCount();
        for (int i=1; i<childCount; i++) card.getChildAt(i).setVisibility(minimized ? View.GONE : View.VISIBLE);
        if (minimized) {
            card.setPadding(16, 8, 16, 8);
            card.setOnClickListener(v -> { minimized=false; updateMinimized(); });
        } else {
            card.setPadding(18, 12, 18, 12);
            card.setOnClickListener(null);
        }
    }

    private void toggleTimer() { if (running) pauseTimer(); else if (remaining < DEFAULT_SECONDS) resumeTimer(); else startTimer(); }
    private void syncFromWeb(Intent intent) {
        if (intent == null) return;
        remaining = Math.max(0L, intent.getLongExtra("remainingSeconds", remaining));
        running = intent.getBooleanExtra("running", false);
        if (running) {
            endAt = System.currentTimeMillis() + remaining * 1000L;
        } else {
            endAt = 0L;
        }
        String label = intent.getStringExtra("label");
        if (statusText != null && label != null && !label.isEmpty()) {
            statusText.setText(running ? label : (intent.getBooleanExtra("paused", false) ? "Paused" : label));
        }
        saveState();
        showOverlay();
        updateControls();
        if (remaining == 0L && running) {
            running = false;
            saveState();
            updateControls();
        }
    }

    private void startTimer() { remaining = remaining <= 0 ? DEFAULT_SECONDS : remaining; endAt = System.currentTimeMillis() + remaining*1000L; running=true; saveState(); updateControls(); }
    private void pauseTimer() { if (!running) return; remaining = Math.max(0, (endAt-System.currentTimeMillis()+999)/1000); running=false; saveState(); updateControls(); }
    private void resumeTimer() { if (remaining <= 0) remaining=DEFAULT_SECONDS; endAt=System.currentTimeMillis()+remaining*1000L; running=true; saveState(); updateControls(); }
    private void stopTimer() { running=false; remaining=DEFAULT_SECONDS; endAt=0; saveState(); updateControls(); }

    private void updateControls() {
        if (actionButton != null) actionButton.setText(running ? "Pause" : (remaining < DEFAULT_SECONDS ? "Resume" : "Start"));
        if (statusText != null) statusText.setText(running ? "Studying" : (remaining < DEFAULT_SECONDS ? "Paused" : "Ready"));
    }

    private void tick() {
        if (running) {
            remaining = Math.max(0, (endAt-System.currentTimeMillis()+999)/1000);
            if (remaining == 0) { running=false; saveState(); updateControls(); }
        }
        if (timerText != null) timerText.setText(format(remaining));
        handler.postDelayed(this::tick, 500);
    }

    private String format(long sec) {
        long h=sec/3600, m=(sec%3600)/60, s=sec%60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h,m,s);
    }

    private void loadState() {
        android.content.SharedPreferences p=getSharedPreferences(PREF,MODE_PRIVATE);
        remaining=p.getLong("remaining",DEFAULT_SECONDS); endAt=p.getLong("endAt",0); running=p.getBoolean("running",false); minimized=p.getBoolean("minimized",false);
        if (running && endAt>0) { remaining=Math.max(0,(endAt-System.currentTimeMillis()+999)/1000); if(remaining==0) running=false; }
    }
    private void saveState() { getSharedPreferences(PREF,MODE_PRIVATE).edit().putLong("remaining",remaining).putLong("endAt",endAt).putBoolean("running",running).putBoolean("minimized",minimized).apply(); }

    @Override public void onDestroy() {
        if (attached && card != null) { try { wm.removeView(card); } catch(Exception ignored){} }
        attached=false; handler.removeCallbacksAndMessages(null); super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
