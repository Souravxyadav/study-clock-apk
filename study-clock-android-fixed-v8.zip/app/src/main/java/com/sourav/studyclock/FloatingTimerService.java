package com.sourav.studyclock;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.Locale;

public class FloatingTimerService extends Service {
    public static final String ACTION_SHOW = "SHOW";
    public static final String ACTION_CLOSE = "CLOSE";
    public static final String ACTION_START = "START";
    public static final String ACTION_PAUSE = "PAUSE";
    public static final String ACTION_RESUME = "RESUME";
    public static final String ACTION_STOP = "STOP";
    public static final String ACTION_SYNC = "SYNC";

    private static final String PREF = "floating_timer";
    private static final String CHANNEL = "study_clock_overlay";
    private static final String COMMAND_KEY = "overlay_command";
    private static final String TEMPLATE_KEY = "template_index";
    private static final long DEFAULT_SECONDS = 25 * 60L;

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private FrameLayout root;
    private LinearLayout expanded;
    private LinearLayout mini;
    private TextView timerText;
    private TextView miniTimerText;
    private TextView statusText;
    private TextView titleText;
    private Button actionButton;
    private Button finishButton;
    private Button templateButton;
    private Handler handler;
    private boolean attached;
    private boolean running;
    private boolean paused;
    private boolean countdownMode = true;
    private boolean minimized;
    private long remaining = DEFAULT_SECONDS;
    private long endAt;
    private long countUpStartedAt;
    private String label = "Study Focus";
    private static FloatingTimerService instance;

    private float downX, downY;
    private int startX, startY;
    private long lastTapAt;
    private boolean moved;

    // 15 clean overlay templates. Tap the small template button to cycle them.
    private static final int[][] TEMPLATES = {
            {0xFFFDFDFD, 0xFFF3F4F6, 0xFFE4573D},
            {0xFF111318, 0xFF1A1D24, 0xFFFF7043},
            {0xFFF7F3FF, 0xFFEDE5FF, 0xFF7C4DFF},
            {0xFFEFF8FF, 0xFFE2F2FF, 0xFF1683D8},
            {0xFFEFFBF5, 0xFFE1F5EA, 0xFF169C62},
            {0xFFFFF8EA, 0xFFFFF0D0, 0xFFD98600},
            {0xFFFFF0F3, 0xFFFFE1E8, 0xFFD83A62},
            {0xFF101B1A, 0xFF182624, 0xFF39C48A},
            {0xFF101722, 0xFF172235, 0xFF4EA1FF},
            {0xFF19131D, 0xFF251B2A, 0xFFCD74FF},
            {0xFFF2F7F6, 0xFFE3EFED, 0xFF2B8F82},
            {0xFFFFF5F0, 0xFFFFE7DC, 0xFFE9683E},
            {0xFFF4F5F7, 0xFFE7E9ED, 0xFF5D6674},
            {0xFFFFF2F2, 0xFFFFE4E4, 0xFFC62828},
            {0xFFEFF7F8, 0xFFDDECEF, 0xFF237B87}
    };

    public static boolean isRunning() { return instance != null; }

    public static void updateFromWeb(long seconds, boolean webRunning, boolean webPaused,
                                     String webLabel, boolean countdown) {
        FloatingTimerService service = instance;
        if (service == null) return;
        service.handler.post(() -> service.applyWebState(seconds, webRunning, webPaused,
                webLabel, countdown));
    }

    public static String consumeOverlayCommand(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        String command = p.getString(COMMAND_KEY, "");
        if (command == null || command.isEmpty()) return "";
        p.edit().remove(COMMAND_KEY).apply();
        return command;
    }

    public static String getOverlayState(Context context) {
        android.content.SharedPreferences p = context.getSharedPreferences(PREF, MODE_PRIVATE);
        JSONObject o = new JSONObject();
        try {
            o.put("seconds", p.getLong("remaining", DEFAULT_SECONDS));
            o.put("running", p.getBoolean("running", false));
            o.put("paused", p.getBoolean("paused", false));
            o.put("countdown", p.getBoolean("countdownMode", true));
            o.put("label", p.getString("label", "Study Focus"));
        } catch (Exception ignored) {}
        return o.toString();
    }

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        handler = new Handler(getMainLooper());
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        startForegroundCompat();
        loadState();
        if (Settings.canDrawOverlays(this)) createOverlay();
        tick();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_SHOW : intent.getAction();
        if (action == null) action = ACTION_SHOW;
        switch (action) {
            case ACTION_START: startTimer(); break;
            case ACTION_PAUSE: pauseTimer(true); break;
            case ACTION_RESUME: resumeTimer(true); break;
            case ACTION_STOP: stopTimer(true); break;
            case ACTION_SYNC: syncFromWeb(intent); break;
            case ACTION_CLOSE: closeOverlay(); break;
            default:
                if (Settings.canDrawOverlays(this) && root == null) createOverlay();
                else showOverlay();
                break;
        }
        return START_STICKY;
    }

    private void startForegroundCompat() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        Notification n = b.setContentTitle("Study Clock")
                .setContentText("Study Focus timer is active")
                .setSmallIcon(com.sourav.studyclock.R.drawable.ic_study_clock)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1001, n, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else startForeground(1001, n);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL, "Study Clock Floating Timer", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Floating Study Focus timer");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }

    private GradientDrawable bg(int color, float radius, int strokeColor) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(1), strokeColor);
        return g;
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setMinHeight(0); b.setMinimumHeight(0);
        b.setPadding(dp(8), 0, dp(8), 0);
        return b;
    }

    private void createOverlay() {
        if (!Settings.canDrawOverlays(this) || root != null) return;

        root = new FrameLayout(this);
        root.setPadding(0, 0, 0, 0);
        root.setBackgroundColor(Color.TRANSPARENT);

        expanded = buildExpandedCard();
        mini = buildMiniCard();
        root.addView(expanded, new FrameLayout.LayoutParams(dp(316), dp(178)));
        FrameLayout.LayoutParams miniLp = new FrameLayout.LayoutParams(dp(174), dp(54));
        miniLp.gravity = Gravity.CENTER;
        root.addView(mini, miniLp);

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL;
        params = new WindowManager.LayoutParams(
                dp(316), dp(178),
                Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE,
                flags, PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = dp(18); params.y = dp(120);
        attachDrag(root);
        applyTemplate();
        showOverlay();
    }

    private LinearLayout buildExpandedCard() {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(12), dp(9), dp(12), dp(10));
        card.setElevation(dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_study_clock);
        logo.setPadding(dp(2), dp(2), dp(2), dp(2));
        header.addView(logo, new LinearLayout.LayoutParams(dp(28), dp(28)));

        LinearLayout titleWrap = new LinearLayout(this);
        titleWrap.setOrientation(LinearLayout.VERTICAL);
        titleWrap.setPadding(dp(7), 0, dp(3), 0);
        titleText = text("Study Focus", 15, Color.DKGRAY);
        titleText.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        statusText = text("Studying", 10, Color.GRAY);
        titleWrap.addView(titleText);
        titleWrap.addView(statusText);
        header.addView(titleWrap, new LinearLayout.LayoutParams(0, dp(42), 1));

        templateButton = button("T1");
        templateButton.setTextSize(16);
        templateButton.setContentDescription("Change floating template");
        templateButton.setOnClickListener(v -> cycleTemplate());
        header.addView(templateButton, new LinearLayout.LayoutParams(dp(36), dp(40)));

        Button min = button("−");
        min.setTextSize(19);
        min.setOnClickListener(v -> setMinimized(true));
        header.addView(min, new LinearLayout.LayoutParams(dp(36), dp(40)));

        Button close = button("×");
        close.setTextSize(20);
        close.setOnClickListener(v -> closeOverlay());
        header.addView(close, new LinearLayout.LayoutParams(dp(36), dp(40)));
        card.addView(header);

        timerText = text(format(remaining), 30, Color.rgb(30,30,34));
        timerText.setGravity(Gravity.CENTER);
        timerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        card.addView(timerText, new LinearLayout.LayoutParams(-1, dp(62)));

        LinearLayout controls = new LinearLayout(this);
        controls.setOrientation(LinearLayout.HORIZONTAL);
        controls.setGravity(Gravity.CENTER);
        actionButton = button("Pause");
        actionButton.setOnClickListener(v -> { if (running) pauseTimer(true); else if (paused) resumeTimer(true); });
        finishButton = button("Finish");
        finishButton.setOnClickListener(v -> stopTimer(true));
        controls.addView(actionButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        controls.addView(finishButton, new LinearLayout.LayoutParams(0, dp(42), 1));
        card.addView(controls);
        return card;
    }

    private LinearLayout buildMiniCard() {
        LinearLayout pill = new LinearLayout(this);
        pill.setOrientation(LinearLayout.HORIZONTAL);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(10), 0, dp(8), 0);
        pill.setElevation(dp(12));

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.ic_study_clock);
        pill.addView(logo, new LinearLayout.LayoutParams(dp(26), dp(26)));
        miniTimerText = text("00:00", 15, Color.DKGRAY);
        miniTimerText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        miniTimerText.setGravity(Gravity.CENTER);
        pill.addView(miniTimerText, new LinearLayout.LayoutParams(0, dp(40), 1));
        Button expand = button("⌃");
        expand.setTextSize(16);
        expand.setOnClickListener(v -> setMinimized(false));
        pill.addView(expand, new LinearLayout.LayoutParams(dp(38), dp(40)));
        pill.setOnClickListener(v -> setMinimized(false));
        return pill;
    }

    private void attachDrag(View handle) {
        handle.setOnTouchListener((v, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX(); downY = event.getRawY();
                    startX = params.x; startY = params.y; moved = false; return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - downX, dy = event.getRawY() - downY;
                    if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) moved = true;
                    if (attached && moved) {
                        params.x = startX + (int) dx; params.y = startY + (int) dy;
                        clampPosition(); wm.updateViewLayout(root, params);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    if (!moved) {
                        long now = System.currentTimeMillis();
                        if (now - lastTapAt < 320) { openApp(); lastTapAt = 0; }
                        else lastTapAt = now;
                    }
                    return true;
            }
            return true;
        });
    }

    private void clampPosition() {
        if (wm == null || root == null) return;
        int width = getResources().getDisplayMetrics().widthPixels;
        int height = getResources().getDisplayMetrics().heightPixels;
        int w = minimized ? dp(174) : dp(316);
        int h = minimized ? dp(54) : dp(178);
        params.x = Math.max(dp(8), Math.min(params.x, width - w - dp(8)));
        params.y = Math.max(dp(8), Math.min(params.y, height - h - dp(8)));
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private void setMinimized(boolean value) {
        minimized = value;
        if (expanded != null) expanded.setVisibility(value ? View.GONE : View.VISIBLE);
        if (mini != null) mini.setVisibility(value ? View.VISIBLE : View.GONE);
        if (root != null && attached) {
            params.width = value ? dp(174) : dp(316);
            params.height = value ? dp(54) : dp(178);
            clampPosition();
            try { wm.updateViewLayout(root, params); } catch (Exception ignored) {}
        }
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean("minimized", value).apply();
    }

    private void showOverlay() {
        if (root == null || !Settings.canDrawOverlays(this)) return;
        if (!attached) {
            try { wm.addView(root, params); attached = true; } catch (Exception ignored) { return; }
        }
        root.setVisibility(View.VISIBLE);
        setMinimized(minimized);
        updateControls();
    }

    private void closeOverlay() {
        if (attached && root != null) {
            try { wm.removeView(root); } catch (Exception ignored) {}
            attached = false;
        }
        saveState();
    }

    private void syncFromWeb(Intent intent) {
        if (intent == null) return;
        applyWebState(
                Math.max(0L, intent.getLongExtra("remainingSeconds", remaining)),
                intent.getBooleanExtra("running", false),
                intent.getBooleanExtra("paused", false),
                intent.getStringExtra("label"),
                intent.getBooleanExtra("countdown", true));
    }

    private void applyWebState(long seconds, boolean webRunning, boolean webPaused, String webLabel, boolean countdown) {
        countdownMode = countdown;
        remaining = Math.max(0L, seconds);
        running = webRunning;
        paused = webPaused;
        label = (webLabel == null || webLabel.trim().isEmpty()) ? "Study Focus" : webLabel;
        long now = System.currentTimeMillis();
        if (countdownMode) { endAt = running ? now + remaining * 1000L : 0L; countUpStartedAt = 0L; }
        else { countUpStartedAt = running ? now - remaining * 1000L : 0L; endAt = 0L; }
        saveState();
        if (running || paused) showOverlay();
        else closeOverlay();
        updateControls();
    }

    private void startTimer() {
        if (remaining <= 0) remaining = DEFAULT_SECONDS;
        paused = false; running = true;
        if (countdownMode) endAt = System.currentTimeMillis() + remaining * 1000L;
        else countUpStartedAt = System.currentTimeMillis() - remaining * 1000L;
        queueCommand("start"); saveState(); updateControls(); showOverlay();
    }

    private void pauseTimer(boolean fromOverlay) {
        if (!running) return;
        long now = System.currentTimeMillis();
        if (countdownMode) remaining = Math.max(0L, (endAt - now + 999L) / 1000L);
        else if (countUpStartedAt > 0) remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
        running = false; paused = true; endAt = 0L;
        if (fromOverlay) queueCommand("pause");
        saveState(); updateControls(); showOverlay();
    }

    private void resumeTimer(boolean fromOverlay) {
        if (!paused) return;
        long now = System.currentTimeMillis();
        if (countdownMode) endAt = now + remaining * 1000L;
        else countUpStartedAt = now - remaining * 1000L;
        running = true; paused = false;
        if (fromOverlay) queueCommand("resume");
        saveState(); updateControls(); showOverlay();
    }

    private void stopTimer(boolean fromOverlay) {
        running = false; paused = false; endAt = 0L; countUpStartedAt = 0L; remaining = 0L;
        if (fromOverlay) queueCommand("finish");
        saveState(); updateControls(); closeOverlay(); stopSelf();
    }

    private void queueCommand(String command) {
        // One queued command is consumed by the WebView and then calls the exact Study-page action.
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putString(COMMAND_KEY, command).apply();
    }

    private void updateControls() {
        if (titleText != null) titleText.setText(label);
        if (statusText != null) statusText.setText(running ? "Studying" : paused ? "Paused" : "Study Focus");
        if (actionButton != null) {
            actionButton.setText(running ? "Pause" : paused ? "Resume" : "Pause");
            actionButton.setEnabled(running || paused);
        }
        if (finishButton != null) finishButton.setEnabled(running || paused);
        if (timerText != null) timerText.setText(format(remaining));
        if (miniTimerText != null) miniTimerText.setText(formatShort(remaining));
    }

    private void applyTemplate() {
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = Math.max(0, Math.min(idx, TEMPLATES.length - 1));
        int bg = TEMPLATES[idx][0], header = TEMPLATES[idx][1], accent = TEMPLATES[idx][2];
        if (templateButton != null) {
            templateButton.setText("T" + (idx + 1));
            templateButton.setContentDescription("Floating template " + (idx + 1) + " of 15. Tap to change");
        }
        if (expanded != null) {
            expanded.setBackground(bg(bg, 20, 0x33909090));
            if (expanded.getChildCount() > 0) expanded.getChildAt(0).setBackground(bg(header, 18, 0x22909090));
        }
        if (mini != null) mini.setBackground(bg(header, 27, 0x33909090));
        if (timerText != null) timerText.setTextColor(accent);
        if (actionButton != null) actionButton.setTextColor(accent);
        if (finishButton != null) finishButton.setTextColor(accent);
        if (templateButton != null) templateButton.setTextColor(accent);
    }

    private void cycleTemplate() {
        int idx = getSharedPreferences(PREF, MODE_PRIVATE).getInt(TEMPLATE_KEY, 0);
        idx = (idx + 1) % TEMPLATES.length;
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt(TEMPLATE_KEY, idx).apply();
        applyTemplate();
    }

    private void tick() {
        if (running) {
            long now = System.currentTimeMillis();
            if (countdownMode) {
                remaining = Math.max(0L, (endAt - now + 999L) / 1000L);
                if (remaining == 0L) {
                    running = false; paused = false;
                    queueCommand("complete"); saveState(); closeOverlay(); stopSelf();
                    return;
                }
            } else if (countUpStartedAt > 0) remaining = Math.max(0L, (now - countUpStartedAt) / 1000L);
            updateControls(); saveState();
        }
        handler.postDelayed(this::tick, 500);
    }

    private String format(long seconds) {
        long h = seconds / 3600, m = (seconds % 3600) / 60, s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d:%02d", h, m, s);
    }

    private String formatShort(long seconds) {
        long m = seconds / 60, s = seconds % 60;
        return String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    private void loadState() {
        android.content.SharedPreferences p = getSharedPreferences(PREF, MODE_PRIVATE);
        remaining = p.getLong("remaining", DEFAULT_SECONDS); endAt = p.getLong("endAt", 0L);
        running = p.getBoolean("running", false); paused = p.getBoolean("paused", false);
        countdownMode = p.getBoolean("countdownMode", true); countUpStartedAt = p.getLong("countUpStartedAt", 0L);
        label = p.getString("label", "Study Focus"); minimized = p.getBoolean("minimized", false);
        if (running) {
            if (countdownMode && endAt > 0) remaining = Math.max(0L, (endAt - System.currentTimeMillis() + 999L) / 1000L);
            else if (!countdownMode && countUpStartedAt > 0) remaining = Math.max(0L, (System.currentTimeMillis() - countUpStartedAt) / 1000L);
        }
    }

    private void saveState() {
        getSharedPreferences(PREF, MODE_PRIVATE).edit()
                .putLong("remaining", remaining).putLong("endAt", endAt)
                .putBoolean("running", running).putBoolean("paused", paused)
                .putBoolean("countdownMode", countdownMode).putLong("countUpStartedAt", countUpStartedAt)
                .putString("label", label).apply();
    }

    @Override public void onDestroy() {
        if (attached && root != null) { try { wm.removeView(root); } catch (Exception ignored) {} }
        attached = false;
        if (handler != null) handler.removeCallbacksAndMessages(null);
        instance = null;
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
